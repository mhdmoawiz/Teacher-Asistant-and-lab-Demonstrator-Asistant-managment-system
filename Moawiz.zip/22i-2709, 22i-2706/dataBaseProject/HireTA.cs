﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Project
{
    public partial class HireTA : Form
    {
        int Id = LoginPage.id;
        public HireTA()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Faculty facultyForm = new Faculty();
            facultyForm.Show();
            this.Hide();
        }

        private void viewBtn_Click(object sender, EventArgs e)
        {
            data();
        }

        private void data()
        {

            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

            using (SqlConnection connections = new SqlConnection(LoginPage.connection))
            {
             
string query = @"
    WITH SortedData AS(
        SELECT
            s.StudentId,
                S.Name AS StudentName,
            C.CourseName,
            Et.EligibleLdID AS EligibleTa,
            tRANS.CGPA,
            Sc.Grade,
            c.CourseID,
            ROW_NUMBER() OVER(PARTITION BY s.StudentId, C.CourseID ORDER BY
                CASE
                    WHEN Sc.Grade = 'A+' THEN 1
                    WHEN Sc.Grade = 'A' THEN 2
                    WHEN Sc.Grade = 'B+' THEN 3
                    WHEN Sc.Grade = 'B' THEN 4
                    WHEN Sc.Grade = 'B-' THEN 5
                    ELSE 6
                END ASC,
                tRANS.CGPA DESC) AS RowNum
        FROM
            Courses c
            INNER JOIN CourseFaculty cf ON c.CourseID = cf.CourseID
            INNER JOIN Faculty f ON cf.FacultyID = f.FacultyId
            INNER JOIN[User] u ON f.UserID = u.ID
            INNER JOIN Teacher T ON T.FacultyId = f.FacultyId
            INNER JOIN TaRequest TR ON TR.CourseID = c.CourseID
            INNER JOIN Eligible_Ta ET ON ET.TaRequestid = TR.TaRequestID
            INNER JOIN Student S ON ET.studentId = S.StudentId
            INNER JOIN Transcript tRANS ON S.StudentId = tRANS.StudentID
            INNER JOIN StudiedCourse SC ON S.StudentId = SC.StudentID AND C.CourseID = SC.CourseID
        WHERE
            u.ID = @Id
    )
    SELECT DISTINCT
        StudentId,
        StudentName,
        CourseName,
        EligibleTa,
        CGPA,
        Grade,
        CourseID
    FROM
        SortedData; ";


                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connections))
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@Id", Id);
                    DataTable dataTable = new DataTable();

                    try
                    {

                        connections.Open();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }

                }
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }




        private void HireButon_Click(object sender, EventArgs e)
        {
           // string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
          //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = @"
            SELECT TOP 1 Et.EligibleLdID, tRANS.CGPA, SC.Grade
            FROM Courses c
            INNER JOIN CourseFaculty cf ON c.CourseID = cf.CourseID
            INNER JOIN Faculty f ON cf.FacultyID = f.FacultyId
            INNER JOIN [User] u ON f.UserID = u.ID
            INNER JOIN Teacher T ON T.FacultyId = f.FacultyId
            INNER JOIN TaRequest TR ON TR.CourseID = c.CourseID
            INNER JOIN Eligible_Ta ET ON ET.TaRequestid = TR.TaRequestID
            INNER JOIN Student S ON ET.studentId = S.StudentId
            INNER JOIN Transcript tRANS ON S.StudentId = tRANS.StudentID
            INNER JOIN StudiedCourse SC ON S.StudentId = SC.StudentID AND C.CourseID = SC.CourseID
            WHERE u.ID = @ID
            ORDER BY SC.Grade DESC, tRANS.CGPA DESC;";

                SqlDataAdapter sd1 = new SqlDataAdapter(query, SqlConnection);
                sd1.SelectCommand.Parameters.AddWithValue("@ID", Id);
                DataTable dtable1 = new DataTable();
                sd1.Fill(dtable1);

                if (dtable1.Rows.Count > 0)
                {
                    int EligibleId = Convert.ToInt32(dtable1.Rows[0]["EligibleLdID"]);

                    string query2 = "SELECT SeletedTaId FROM SelectedTa \r\nWHERE eligibleid = @Eid ";

                   
                    
                    if (EligibleId > 0)
                    {
                        SqlDataAdapter sd2 = new SqlDataAdapter(query2, SqlConnection);
                        sd2.SelectCommand.Parameters.AddWithValue("@Eid", EligibleId);
                        DataTable dtable3 = new DataTable();
                        sd2.Fill(dtable3);

                        if (dtable3.Rows.Count == 0)
                        {
                           string insertQuery = "INSERT INTO SelectedTa (eligibleid) VALUES (@Eid);";

                            using (SqlCommand cmd = new SqlCommand(insertQuery, SqlConnection))
                            {
                                cmd.Parameters.AddWithValue("@Eid", EligibleId);
                                try
                                {
                                    SqlConnection.Open();
                                    cmd.ExecuteNonQuery();
                                    MessageBox.Show("TA hired successfully!");
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Error: " + ex.Message);
                                }
                            }
                        }


                     
                            else
                        {
                            MessageBox.Show("request already completed ");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Wrong Eligible ID");
                    }
                }
                else
                {
                    MessageBox.Show("No eligible TA found.");
                }
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            string Eid = textBox2.Text;
            int Number;
            try
            {

                if (int.TryParse(Eid, out Number))
                {
                  //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
                    //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
                    using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
                    {



                        string query2 = "SELECT SeletedTaId FROM SelectedTa \r\nWHERE eligibleid = @Eid ";

                        SqlDataAdapter sd2 = new SqlDataAdapter(query2, SqlConnection);
                        sd2.SelectCommand.Parameters.AddWithValue("@Eid", Number);
                        DataTable dtable3 = new DataTable();
                        sd2.Fill(dtable3);
                        if (dtable3.Rows.Count == 0)
                        {

                            string query5 = @"
    SELECT ET.studentId 
    FROM Eligible_Ta Et 
    INNER JOIN TaRequest Tr ON Et.TaRequestid = Tr.TaRequestID
    INNER JOIN Teacher t ON Tr.Teacher = T.TeacherId
    INNER JOIN Faculty F ON T.FacultyId = F.FacultyId
    INNER JOIN [User] u ON u.ID = @id AND ET.EligibleLdID = @Eid;";

                            SqlDataAdapter sd4 = new SqlDataAdapter(query5, SqlConnection);
                            sd4.SelectCommand.Parameters.AddWithValue("@Eid", Id);
                            sd4.SelectCommand.Parameters.AddWithValue("@id", Number);
                            DataTable dtable4 = new DataTable();
                            sd2.Fill(dtable4);


                            if (dtable4.Rows.Count == 0)
                            {
                                MessageBox.Show("you cannot add this student as he has not applied for your course");
                            }

                            else
                            {

                                string query1 = "INSERT INTO SelectedTa (eligibleid) VALUES (@Eid);";

                                SqlDataAdapter sd1 = new SqlDataAdapter(query1, SqlConnection);
                                sd1.SelectCommand.Parameters.AddWithValue("@Eid", Number);
                                DataTable dtable2 = new DataTable();
                                sd1.Fill(dtable2);
                                MessageBox.Show("Data inserted to data base ");
                                textBox2.Clear();
                            }



                        }







                        else
                        {
                            MessageBox.Show("already added");
                        }



                    }
                }
                else
                {

                    MessageBox.Show("Eid must be a valid integer.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
