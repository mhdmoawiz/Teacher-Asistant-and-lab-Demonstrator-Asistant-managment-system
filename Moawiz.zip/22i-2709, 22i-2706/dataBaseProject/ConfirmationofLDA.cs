﻿/*using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ConfirmationofLDA : Form
    {
        public ConfirmationofLDA()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConfirmationofLDA confirmationofLDA = new ConfirmationofLDA();
            confirmationofLDA.Show();
            this.Hide();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
        }
    }
}
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ConfirmationofLDA : Form
    {
        public ConfirmationofLDA()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(Studentid.Text))
            {
                call();
                ConfirmationofLDA confirmationofLDA = new ConfirmationofLDA();
                confirmationofLDA.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter confirmation Request ID.");
            }
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(Studentid.Text))
            {
                call();
                Student studentForm = new Student();
                studentForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter confirmation Request ID.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void ViewBtn_Click(object sender, EventArgs e)
        {







        }
        /*private void call()
        {
            int selectedLDid = Convert.ToInt32(Studentid.Text);
            string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(connection))
            {
                string query = "\r\nselect lr.CourseID,lr.labDemonstrator,ed.studentId,lr.LdaRequestID,ed.EligibleLdID from Selected_LDA sl join Eligible_LDA ed on ed.EligibleLdID=sl.eligible join LdaRequest lr on lr.LdaRequestID=ed.LdaRequestid where sl.SeletedLda=@selectedLDid\r\n";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@selectedLDid", selectedLDid);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                int courseid = Convert.ToInt32(dt.Rows[0]["CourseID"]);
                int labDemonstratorid = Convert.ToInt32(dt.Rows[0]["labDemonstrator"]);
                int studentid = Convert.ToInt32(dt.Rows[0]["studentId"]);
                int LDARequestid = Convert.ToInt32(dt.Rows[0]["LdaRequestID"]);
                int EligibleLdID = Convert.ToInt32(dt.Rows[0]["EligibleLdID"]);
                
               if(dt.Rows.Count == 0)
                {
                    MessageBox.Show("You are not selected yet");
                }
                else
                {
                    


                //write qurry for insertion 
                string query1 = "insert into LabDemostratorAsisitant values(@studentId,@CourseID,@labDemonstrator)";
                SqlCommand command = new SqlCommand(query1, SqlConnection);
                command.Parameters.AddWithValue("@studentId", studentid);
                command.Parameters.AddWithValue("@CourseID", courseid);
                command.Parameters.AddWithValue("@labDemonstrator", labDemonstratorid);
                SqlConnection.Open();
                command.ExecuteNonQuery();
                SqlConnection.Close();

               //write a querry to delete the selected LDA from the selected LDA table
                string query2 = "delete from Selected_LDA where SeletedLda=@selectedLDid";
                SqlCommand command2 = new SqlCommand(query2, SqlConnection);
                command2.Parameters.AddWithValue("@selectedLDid", selectedLDid);
                SqlConnection.Open();
                command2.ExecuteNonQuery();
                SqlConnection.Close();

                //write a querry to delete the selected LDA from the Eligible LDA table
                string query3 = "delete from Eligible_LDA where EligibleLdID=@EligibleLdID";
                SqlCommand command3 = new SqlCommand(query3, SqlConnection);
                command3.Parameters.AddWithValue("@EligibleLdID", EligibleLdID);
                SqlConnection.Open();
                command3.ExecuteNonQuery();
                SqlConnection.Close();

                //write a querry to delete the selected LDA from the LDA request table
                string query4 = "delete from LdaRequest where LdaRequestID=@LDARequestid";
                SqlCommand command4 = new SqlCommand(query4, SqlConnection);
                command4.Parameters.AddWithValue("@LDARequestid", LDARequestid);
                SqlConnection.Open();
                command4.ExecuteNonQuery();
                SqlConnection.Close();



                
                 MessageBox.Show("You are successfully added as Lab Demonstrator Assistant");
                 }

            }

        }*/
        private void call()
        {
            int selectedLDid = Convert.ToInt32(Studentid.Text);
            //    string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

           // string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "SELECT lr.CourseID, lr.labDemonstrator, ed.studentId, lr.LdaRequestID, ed.EligibleLdID FROM Selected_LDA sl JOIN Eligible_LDA ed ON ed.EligibleLdID = sl.eligible JOIN LdaRequest lr ON lr.LdaRequestID = ed.LdaRequestid WHERE sl.SeletedLda = @selectedLDid";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@selectedLDid", selectedLDid);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("You are not selected yet");
                }
                else
                {
                    int courseid = Convert.ToInt32(dt.Rows[0]["CourseID"]);
                    int labDemonstratorid = Convert.ToInt32(dt.Rows[0]["labDemonstrator"]);
                    int studentid = Convert.ToInt32(dt.Rows[0]["studentId"]);
                    int LDARequestid = Convert.ToInt32(dt.Rows[0]["LdaRequestID"]);
                    int EligibleLdID = Convert.ToInt32(dt.Rows[0]["EligibleLdID"]);

                    // Insert into LabDemostratorAsisitant table
                    /*string insertQuery = "INSERT INTO LabDemostratorAsisitant (studentId, CourseID, labDemonstratorId) VALUES (@studentId, @CourseID, @labDemonstrator)";
                    SqlCommand command = new SqlCommand(insertQuery, SqlConnection);
                    command.Parameters.AddWithValue("@studentId", studentid);
                    command.Parameters.AddWithValue("@CourseID", courseid);
                    command.Parameters.AddWithValue("@labDemonstrator", labDemonstratorid);
                    SqlConnection.Open();
                    command.ExecuteNonQuery();*/
                    string insertQuery = "INSERT INTO LabDemostratorAsisitant (studentId, CourseID, LabDemostratorId) VALUES (@studentId, @CourseID, @labDemonstrator)";
                    SqlCommand command = new SqlCommand(insertQuery, SqlConnection);
                    command.Parameters.AddWithValue("@studentId", studentid);
                    command.Parameters.AddWithValue("@CourseID", courseid);
                    command.Parameters.AddWithValue("@labDemonstrator", labDemonstratorid);
                    SqlConnection.Open();
                    command.ExecuteNonQuery();
                    // Delete from Selected_LDA table
                    string deleteSelectedLdaQuery = "DELETE FROM Selected_LDA WHERE SeletedLda = @selectedLDid";
                    SqlCommand deleteSelectedLdaCommand = new SqlCommand(deleteSelectedLdaQuery, SqlConnection);
                    deleteSelectedLdaCommand.Parameters.AddWithValue("@selectedLDid", selectedLDid);
                    deleteSelectedLdaCommand.ExecuteNonQuery();

                    // Delete from Eligible_LDA table
                    string deleteEligibleLdaQuery = "DELETE FROM Eligible_LDA WHERE EligibleLdID = @EligibleLdID";
                    SqlCommand deleteEligibleLdaCommand = new SqlCommand(deleteEligibleLdaQuery, SqlConnection);
                    deleteEligibleLdaCommand.Parameters.AddWithValue("@EligibleLdID", EligibleLdID);
                    deleteEligibleLdaCommand.ExecuteNonQuery();

                    // Delete from LdaRequest table
                    string deleteLdaRequestQuery = "DELETE FROM LdaRequest WHERE LdaRequestID = @LDARequestid";
                    SqlCommand deleteLdaRequestCommand = new SqlCommand(deleteLdaRequestQuery, SqlConnection);
                    deleteLdaRequestCommand.Parameters.AddWithValue("@LDARequestid", LDARequestid);
                    deleteLdaRequestCommand.ExecuteNonQuery();

                    SqlConnection.Close();

                    MessageBox.Show("You are successfully added as Lab Demonstrator Assistant");
                }
            }
        }

        private void Studentid_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ViewBtn_Click_1(object sender, EventArgs e)
        {
            //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "SELECT s.SeletedLda, c.CourseName, f.Name, sch.Data, sch.StartingTime, sch.EndingTime FROM Selected_LDA s" +
                " JOIN Eligible_LDA et ON et.EligibleLdID = s.eligible" +
                " JOIN LdaRequest tr ON tr.LdaRequestID = et.LdaRequestid" +
                " JOIN Courses c ON c.CourseID = tr.CourseID" +
                " JOIN Schedule sch ON sch.CourseID = c.CourseID" +
                " JOIN LabDemostrator t ON t.LabDemostratorID = tr.labDemonstrator" +
                " JOIN Faculty f ON f.FacultyId = t.FactaryID" +
                " JOIN Student st ON st.StudentId = et.studentId" +
                " JOIN [User] u ON u.ID = st.UserID" +
                " WHERE u.ID = @id;";


                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@id", LoginPage.id);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("You are not selected yet");
                }
                else
                {
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            //string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
           // string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "SELECT s.Name AS StudentName, c.CourseName, sch.Data AS Day," +
                 "  sch.StartingTime, sch.EndingTime FROM [User] u" +
                 " JOIN Student s ON u.ID = s.UserID " +
                 " JOIN StudentCourse sc ON s.StudentId = sc.StudentID " +
                 " JOIN Schedule sch ON sc.CourseID = sch.CourseID " +
                 " JOIN Courses c ON sc.CourseID = c.CourseID" +
                 " WHERE u.ID = @id;";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@id", LoginPage.id);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView2.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
