﻿namespace Project
{
    partial class LdAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            textBox8 = new TextBox();
            label10 = new Label();
            label3 = new Label();
            textBox7 = new TextBox();
            label9 = new Label();
            label8 = new Label();
            textBox6 = new TextBox();
            label6 = new Label();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            button2 = new Button();
            label5 = new Label();
            textBox2 = new TextBox();
            button1 = new Button();
            textBox1 = new TextBox();
            label2 = new Label();
            LoginButton = new Button();
            Studentid = new TextBox();
            BackButton = new Button();
            ViewBtn = new Button();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            label7 = new Label();
            textBox5 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Arial Narrow", 12F);
            label4.ForeColor = SystemColors.Desktop;
            label4.Location = new Point(101, 367);
            label4.Name = "label4";
            label4.Size = new Size(93, 20);
            label4.TabIndex = 107;
            label4.Text = "Student-Name";
            // 
            // textBox8
            // 
            textBox8.BackColor = Color.White;
            textBox8.Location = new Point(302, 335);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(105, 23);
            textBox8.TabIndex = 106;
            textBox8.TextAlign = HorizontalAlignment.Center;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.FlatStyle = FlatStyle.Flat;
            label10.Font = new Font("Arial Narrow", 12F);
            label10.ForeColor = SystemColors.Desktop;
            label10.Location = new Point(302, 312);
            label10.Name = "label10";
            label10.Size = new Size(90, 20);
            label10.TabIndex = 105;
            label10.Text = "Faculty-Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Arial Narrow", 12F);
            label3.ForeColor = SystemColors.Desktop;
            label3.Location = new Point(101, 316);
            label3.Name = "label3";
            label3.Size = new Size(93, 20);
            label3.TabIndex = 104;
            label3.Text = "Student-Name";
            // 
            // textBox7
            // 
            textBox7.BackColor = Color.White;
            textBox7.Location = new Point(302, 281);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(105, 23);
            textBox7.TabIndex = 103;
            textBox7.TextAlign = HorizontalAlignment.Center;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.FlatStyle = FlatStyle.Flat;
            label9.Font = new Font("Arial Narrow", 12F);
            label9.ForeColor = SystemColors.Desktop;
            label9.Location = new Point(485, 258);
            label9.Name = "label9";
            label9.Size = new Size(87, 20);
            label9.TabIndex = 102;
            label9.Text = "CourseName";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Arial Narrow", 12F);
            label8.ForeColor = SystemColors.Desktop;
            label8.Location = new Point(302, 258);
            label8.Name = "label8";
            label8.Size = new Size(90, 20);
            label8.TabIndex = 101;
            label8.Text = "Faculty-Name";
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.White;
            textBox6.Location = new Point(485, 281);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(105, 23);
            textBox6.TabIndex = 100;
            textBox6.TextAlign = HorizontalAlignment.Center;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Arial Narrow", 12F);
            label6.ForeColor = SystemColors.Desktop;
            label6.Location = new Point(485, 367);
            label6.Name = "label6";
            label6.Size = new Size(87, 20);
            label6.TabIndex = 97;
            label6.Text = "CourseName";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.White;
            textBox4.Location = new Point(302, 390);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(105, 23);
            textBox4.TabIndex = 96;
            textBox4.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.White;
            textBox3.Location = new Point(485, 390);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(105, 23);
            textBox3.TabIndex = 95;
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.HotTrack;
            button2.ForeColor = SystemColors.ActiveCaptionText;
            button2.Location = new Point(671, 380);
            button2.Name = "button2";
            button2.Size = new Size(106, 33);
            button2.TabIndex = 94;
            button2.Text = "Update";
            button2.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Arial Narrow", 12F);
            label5.ForeColor = SystemColors.Desktop;
            label5.Location = new Point(302, 367);
            label5.Name = "label5";
            label5.Size = new Size(99, 20);
            label5.TabIndex = 93;
            label5.Text = "New Student Id";
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.White;
            textBox2.Location = new Point(101, 390);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(105, 23);
            textBox2.TabIndex = 92;
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.HotTrack;
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(671, 329);
            button1.Name = "button1";
            button1.Size = new Size(106, 33);
            button1.TabIndex = 91;
            button1.Text = "Delete";
            button1.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.White;
            textBox1.Location = new Point(101, 339);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(105, 23);
            textBox1.TabIndex = 90;
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Arial Narrow", 12F);
            label2.ForeColor = SystemColors.Desktop;
            label2.Location = new Point(101, 258);
            label2.Name = "label2";
            label2.Size = new Size(93, 20);
            label2.TabIndex = 89;
            label2.Text = "Student-Name";
            // 
            // LoginButton
            // 
            LoginButton.BackColor = SystemColors.HotTrack;
            LoginButton.ForeColor = SystemColors.ActiveCaptionText;
            LoginButton.Location = new Point(671, 271);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(106, 33);
            LoginButton.TabIndex = 88;
            LoginButton.Text = "Add";
            LoginButton.UseVisualStyleBackColor = false;
            // 
            // Studentid
            // 
            Studentid.BackColor = Color.White;
            Studentid.Location = new Point(101, 281);
            Studentid.Name = "Studentid";
            Studentid.Size = new Size(105, 23);
            Studentid.TabIndex = 87;
            Studentid.TextAlign = HorizontalAlignment.Center;
            // 
            // BackButton
            // 
            BackButton.BackColor = SystemColors.ControlDark;
            BackButton.ForeColor = Color.Black;
            BackButton.Location = new Point(24, 38);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(106, 28);
            BackButton.TabIndex = 86;
            BackButton.Text = "Back";
            BackButton.UseVisualStyleBackColor = false;
            // 
            // ViewBtn
            // 
            ViewBtn.BackColor = SystemColors.Highlight;
            ViewBtn.ForeColor = SystemColors.Control;
            ViewBtn.Location = new Point(671, 118);
            ViewBtn.Name = "ViewBtn";
            ViewBtn.Size = new Size(106, 28);
            ViewBtn.TabIndex = 85;
            ViewBtn.Text = "View";
            ViewBtn.UseVisualStyleBackColor = false;
            ViewBtn.Click += ViewBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Arial Narrow", 20.25F, FontStyle.Bold);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(235, 74);
            label1.Name = "label1";
            label1.Size = new Size(352, 31);
            label1.TabIndex = 84;
            label1.Text = "Lab Demostrator  Asistance List";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(101, 118);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(541, 132);
            dataGridView1.TabIndex = 83;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.FlatStyle = FlatStyle.Flat;
            label7.Font = new Font("Arial Narrow", 12F);
            label7.ForeColor = SystemColors.Desktop;
            label7.Location = new Point(485, 316);
            label7.Name = "label7";
            label7.Size = new Size(87, 20);
            label7.TabIndex = 99;
            label7.Text = "CourseName";
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.White;
            textBox5.Location = new Point(485, 339);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(105, 23);
            textBox5.TabIndex = 98;
            textBox5.TextAlign = HorizontalAlignment.Center;
            // 
            // LdAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(textBox8);
            Controls.Add(label10);
            Controls.Add(label3);
            Controls.Add(textBox7);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(textBox6);
            Controls.Add(label7);
            Controls.Add(textBox5);
            Controls.Add(label6);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(button2);
            Controls.Add(label5);
            Controls.Add(textBox2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(LoginButton);
            Controls.Add(Studentid);
            Controls.Add(BackButton);
            Controls.Add(ViewBtn);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "LdAdmin";
            Text = "LdAdmin";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label4;
        private TextBox textBox8;
        private Label label10;
        private Label label3;
        private TextBox textBox7;
        private Label label9;
        private Label label8;
        private TextBox textBox6;
        private Label label6;
        private TextBox textBox4;
        private TextBox textBox3;
        private Button button2;
        private Label label5;
        private TextBox textBox2;
        private Button button1;
        private TextBox textBox1;
        private Label label2;
        private Button LoginButton;
        private TextBox Studentid;
        private Button BackButton;
        private Button ViewBtn;
        private Label label1;
        private DataGridView dataGridView1;
        private Label label7;
        private TextBox textBox5;
    }
}