﻿namespace Project
{
    partial class ConfirmationofTA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            LoginButton = new Button();
            button2 = new Button();
            label4 = new Label();
            dataGridView2 = new DataGridView();
            label3 = new Label();
            label2 = new Label();
            Studentid = new TextBox();
            BackButton = new Button();
            ViewBtn = new Button();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.HotTrack;
            button1.FlatStyle = FlatStyle.Popup;
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(427, 391);
            button1.Name = "button1";
            button1.Size = new Size(164, 33);
            button1.TabIndex = 81;
            button1.Text = "Confirm for more";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // LoginButton
            // 
            LoginButton.BackColor = SystemColors.HotTrack;
            LoginButton.FlatStyle = FlatStyle.Popup;
            LoginButton.ForeColor = SystemColors.ActiveCaptionText;
            LoginButton.Location = new Point(597, 391);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(170, 33);
            LoginButton.TabIndex = 80;
            LoginButton.Text = "Confirm";
            LoginButton.UseVisualStyleBackColor = false;
            LoginButton.Click += LoginButton_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.Highlight;
            button2.FlatStyle = FlatStyle.Popup;
            button2.ForeColor = SystemColors.Control;
            button2.Location = new Point(657, 312);
            button2.Name = "button2";
            button2.Size = new Size(106, 28);
            button2.TabIndex = 79;
            button2.Text = "View";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click_1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Arial Narrow", 20.25F, FontStyle.Bold);
            label4.ForeColor = SystemColors.HotTrack;
            label4.Location = new Point(427, 91);
            label4.Name = "label4";
            label4.Size = new Size(213, 31);
            label4.TabIndex = 78;
            label4.Text = "Student TimeTable";
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(427, 125);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.Size = new Size(336, 177);
            dataGridView2.TabIndex = 77;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.FromArgb(192, 0, 0);
            label3.Location = new Point(65, 315);
            label3.Name = "label3";
            label3.Size = new Size(228, 15);
            label3.TabIndex = 76;
            label3.Text = "Plese Enter the Eligible Id for confirmation";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Arial Narrow", 12F);
            label2.ForeColor = SystemColors.Desktop;
            label2.Location = new Point(69, 368);
            label2.Name = "label2";
            label2.Size = new Size(78, 20);
            label2.TabIndex = 75;
            label2.Text = "Selected Id";
            // 
            // Studentid
            // 
            Studentid.BackColor = Color.White;
            Studentid.Location = new Point(69, 391);
            Studentid.Name = "Studentid";
            Studentid.Size = new Size(204, 23);
            Studentid.TabIndex = 74;
            Studentid.TextAlign = HorizontalAlignment.Center;
            // 
            // BackButton
            // 
            BackButton.BackColor = SystemColors.ControlDark;
            BackButton.FlatStyle = FlatStyle.Popup;
            BackButton.ForeColor = Color.Black;
            BackButton.Location = new Point(32, 37);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(106, 28);
            BackButton.TabIndex = 73;
            BackButton.Text = "Back";
            BackButton.UseVisualStyleBackColor = false;
            BackButton.Click += BackButton_Click;
            // 
            // ViewBtn
            // 
            ViewBtn.BackColor = SystemColors.Highlight;
            ViewBtn.FlatStyle = FlatStyle.Popup;
            ViewBtn.ForeColor = SystemColors.Control;
            ViewBtn.Location = new Point(299, 308);
            ViewBtn.Name = "ViewBtn";
            ViewBtn.Size = new Size(106, 28);
            ViewBtn.TabIndex = 72;
            ViewBtn.Text = "View";
            ViewBtn.UseVisualStyleBackColor = false;
            ViewBtn.Click += ViewBtn_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Arial Narrow", 20.25F, FontStyle.Bold);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(69, 91);
            label1.Name = "label1";
            label1.Size = new Size(235, 31);
            label1.TabIndex = 71;
            label1.Text = "Confirm For TA-Ship";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(69, 125);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(336, 177);
            dataGridView1.TabIndex = 70;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // ConfirmationofTA
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(LoginButton);
            Controls.Add(button2);
            Controls.Add(label4);
            Controls.Add(dataGridView2);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(Studentid);
            Controls.Add(BackButton);
            Controls.Add(ViewBtn);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "ConfirmationofTA";
            Text = "ConfirmationofTA";
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button LoginButton;
        private Button button2;
        private Label label4;
        private DataGridView dataGridView2;
        private Label label3;
        private Label label2;
        private TextBox Studentid;
        private Button BackButton;
        private Button ViewBtn;
        private Label label1;
        private DataGridView dataGridView1;
    }
}