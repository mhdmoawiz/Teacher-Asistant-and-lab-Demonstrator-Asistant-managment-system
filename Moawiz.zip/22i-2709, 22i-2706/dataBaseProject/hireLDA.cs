﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class hireLDA : Form
    {
        int id = LoginPage.id;
        public hireLDA()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Faculty facultyForm = new Faculty();
            facultyForm.Show();
            this.Hide();
        }

        private void ViewBtn_Click(object sender, EventArgs e)
        {
            data();
        }

        private void data()
        {

            // string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
           // string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

            using (SqlConnection connections = new SqlConnection(LoginPage.connection))
            {
                string query = @"
    WITH SortedData AS (
        SELECT  
            s.StudentId,
            S.Name,
            C.CourseName,
            ED.EligibleLdID AS eligibleLDid,
            tRANS.CGPA,
            Sc.Grade,
            c.CourseID,
            ROW_NUMBER() OVER (PARTITION BY s.StudentId, C.CourseID ORDER BY
                CASE
                    WHEN Sc.Grade = 'A+' THEN 1
                    WHEN Sc.Grade = 'A' THEN 2
                    WHEN Sc.Grade = 'B+' THEN 3
                    WHEN Sc.Grade = 'B' THEN 4
                    WHEN Sc.Grade = 'B-' THEN 5
                    ELSE 6
                END ASC,
                tRANS.CGPA DESC) AS RowNum
        FROM
            Courses c
            INNER JOIN CourseFaculty cf ON c.CourseID = cf.CourseID
            INNER JOIN Faculty f ON cf.FacultyID = f.FacultyId
            INNER JOIN [User] u ON f.UserID = u.ID
            INNER JOIN LabDemostrator Ld ON Ld.FactaryID = f.FacultyId
            INNER JOIN LdaRequest LDA ON LDA.CourseID = c.CourseID
            INNER JOIN Eligible_LDA ED ON ED.LdaRequestid = LDA.LdaRequestID
            INNER JOIN Student S on ED.studentId = S.StudentId
            INNER JOIN Transcript tRANS ON S.StudentId = tRANS.StudentID
            INNER JOIN StudiedCourse SC ON S.StudentId = SC.StudentID AND C.CourseID = SC.CourseID
            where u.ID = @Id)
    SELECT DISTINCT
        StudentId,
        Name,
        CourseName,
        eligibleLDid,
        CGPA,
        Grade,
        CourseID
    FROM
        SortedData;";

                // Now you can use the 'queryString' variable wherever you need the SQL query as a string.

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connections))
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@Id", id);
                    DataTable dataTable = new DataTable();

                    try
                    {

                        connections.Open();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }

                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {





            //string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = @"
            SELECT TOP 1 ED.EligibleLdID, tRANS.CGPA, SC.Grade
            FROM Courses c
            INNER JOIN CourseFaculty cf ON c.CourseID = cf.CourseID
            INNER JOIN Faculty f ON cf.FacultyID = f.FacultyId
            INNER JOIN [User] u ON f.UserID = u.ID
            INNER JOIN LabDemostrator Ld ON Ld.FactaryID = f.FacultyId
            INNER JOIN LdaRequest LDA ON LDA.CourseID = c.CourseID
            INNER JOIN Eligible_LDA ED ON ED.LdaRequestid = LDA.LdaRequestID
            INNER JOIN Student S on ED.studentId = S.StudentId
            INNER JOIN Transcript tRANS ON S.StudentId = tRANS.StudentID
            INNER JOIN StudiedCourse SC ON S.StudentId = SC.StudentID AND C.CourseID = SC.CourseID
            WHERE u.ID = @ID
            ORDER BY SC.Grade DESC, tRANS.CGPA DESC;";

                SqlDataAdapter sd1 = new SqlDataAdapter(query, SqlConnection);
                sd1.SelectCommand.Parameters.AddWithValue("@ID", id);
                DataTable dtable1 = new DataTable();
                sd1.Fill(dtable1);

                if (dtable1.Rows.Count > 0)
                {
                    int EligibleId = Convert.ToInt32(dtable1.Rows[0]["EligibleLdID"]);

                    string query2 = "SELECT SeletedLda FROM Selected_LDA \r\nWHERE eligible = @Eid ";



                    if (EligibleId > 0)
                    {
                        SqlDataAdapter sd2 = new SqlDataAdapter(query2, SqlConnection);
                        sd2.SelectCommand.Parameters.AddWithValue("@Eid", EligibleId);
                        DataTable dtable3 = new DataTable();
                        sd2.Fill(dtable3);
                        sd2.Fill(dtable3);

                        if (dtable3.Rows.Count == 0)
                        {
                            string insertQuery = "INSERT INTO Selected_LDa (eligible) VALUES (@Eid);";

                            using (SqlCommand cmd = new SqlCommand(insertQuery, SqlConnection))
                            {
                                cmd.Parameters.AddWithValue("@Eid", EligibleId);
                                try
                                {
                                    SqlConnection.Open();
                                    cmd.ExecuteNonQuery();
                                    MessageBox.Show("TA hired successfully!");
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Error: " + ex.Message);
                                }
                            }
                        }



                        else
                        {
                            MessageBox.Show("request already completed ");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Wrong Eligible ID");
                    }
                }
                else
                {
                    MessageBox.Show("No eligible TA found.");
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
