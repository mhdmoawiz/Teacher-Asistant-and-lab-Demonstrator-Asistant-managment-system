﻿namespace Project
{
    partial class Ldarequestsfrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BackButton = new Button();
            label1 = new Label();
            label4 = new Label();
            dataGridView1 = new DataGridView();
            label3 = new Label();
            FacultyName = new TextBox();
            label2 = new Label();
            LoginButton = new Button();
            CourseName = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // BackButton
            // 
            BackButton.BackColor = SystemColors.ControlDark;
            BackButton.ForeColor = Color.Black;
            BackButton.Location = new Point(12, 23);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(106, 28);
            BackButton.TabIndex = 53;
            BackButton.Text = "Back";
            BackButton.UseVisualStyleBackColor = false;
            BackButton.Click += BackButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Arial Narrow", 20.25F, FontStyle.Bold);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(206, 53);
            label1.Name = "label1";
            label1.Size = new Size(420, 31);
            label1.TabIndex = 52;
            label1.Text = "Lab Demonstrator Assistance Request";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.Desktop;
            label4.Location = new Point(467, 118);
            label4.Name = "label4";
            label4.Size = new Size(101, 18);
            label4.TabIndex = 60;
            label4.Text = "Your Courses";
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.ColumnHeader;
            dataGridView1.BackgroundColor = SystemColors.AppWorkspace;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = SystemColors.InactiveCaptionText;
            dataGridView1.Location = new Point(467, 139);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(321, 169);
            dataGridView1.TabIndex = 59;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Arial Narrow", 12F);
            label3.ForeColor = SystemColors.Desktop;
            label3.Location = new Point(127, 209);
            label3.Name = "label3";
            label3.Size = new Size(90, 20);
            label3.TabIndex = 58;
            label3.Text = "Faculty Name";
            // 
            // FacultyName
            // 
            FacultyName.BackColor = Color.White;
            FacultyName.Location = new Point(248, 206);
            FacultyName.Name = "FacultyName";
            FacultyName.Size = new Size(177, 23);
            FacultyName.TabIndex = 57;
            FacultyName.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Arial Narrow", 12F);
            label2.ForeColor = SystemColors.Desktop;
            label2.Location = new Point(126, 151);
            label2.Name = "label2";
            label2.Size = new Size(91, 20);
            label2.TabIndex = 56;
            label2.Text = "Course Name";
            // 
            // LoginButton
            // 
            LoginButton.BackColor = SystemColors.HotTrack;
            LoginButton.ForeColor = SystemColors.ActiveCaptionText;
            LoginButton.Location = new Point(248, 275);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(95, 33);
            LoginButton.TabIndex = 55;
            LoginButton.Text = "Add";
            LoginButton.UseVisualStyleBackColor = false;
            LoginButton.Click += LoginButton_Click;
            // 
            // CourseName
            // 
            CourseName.BackColor = Color.White;
            CourseName.Location = new Point(248, 148);
            CourseName.Name = "CourseName";
            CourseName.Size = new Size(177, 23);
            CourseName.TabIndex = 54;
            CourseName.TextAlign = HorizontalAlignment.Center;
            // 
            // Ldarequestsfrom
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(dataGridView1);
            Controls.Add(label3);
            Controls.Add(FacultyName);
            Controls.Add(label2);
            Controls.Add(LoginButton);
            Controls.Add(CourseName);
            Controls.Add(BackButton);
            Controls.Add(label1);
            Name = "Ldarequestsfrom";
            Text = "Ldarequestsfrom";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button BackButton;
        private Label label1;
        private Label label4;
        private DataGridView dataGridView1;
        private Label label3;
        private TextBox FacultyName;
        private Label label2;
        private Button LoginButton;
        private TextBox CourseName;
    }
}