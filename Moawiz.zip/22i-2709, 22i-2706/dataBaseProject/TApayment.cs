﻿/*using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class TApayment : Form
    {
        public TApayment()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void ViewBtn_Click(object sender, EventArgs e)
        {

        }
    }
}
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class TApayment : Form
    {
        int id = LoginPage.id;
        public TApayment()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        /*private void ViewBtn_Click(object sender, EventArgs e)
        {
            string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(connection))
            {
                string query1 = "Select * from Selected_Ta st   " +
                    " join Eligible_Ta et on et.EligibleLdID=st.eligible " +
                    "join Eligible_Ta et on et.EligibleLdID=st.eligible" +
                    " join Student s  on s.StudentId=et.studentId" +
                    " join [User] u on u.ID=s.UserID " +
                    "where u.ID=@id";
                SqlDataAdapter sda1 = new SqlDataAdapter(query1, SqlConnection);
                sda1.SelectCommand.Parameters.AddWithValue("@id", id);
                DataTable dtable = new DataTable();
                sda1.Fill(dtable);
                String Type = dtable.Rows[0]["Type"].ToString();


                if (Type == "p")
                {
                    string query = "Select NumberOfAssigment,NumberOfAssigment*250 as Total from Selected_Ta st   " +
                    " join Eligible_Ta et on et.EligibleLdID=st.eligible " +
                    " join Student s  on s.StudentId=et.studentId" +
                    " join [User] u on u.ID=s.UserID " +
                    "where u.ID=1";
                    SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                else if (Type == "h")
                {
                    string query = "Select NumberOfAssigment,NumberOfAssigment*190 as Total from Selected_Ta st   " +
                    " join Eligible_Ta et on et.EligibleLdID=st.eligible " +
                    " join Student s  on s.StudentId=et.studentId" +
                    " join [User] u on u.ID=s.UserID " +
                    "where u.ID=1";
                    SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                else if (Type == "m")
                {
                    string query = "Select NumberOfAssigment,NumberOfAssigment*150 as Total from Selected_Ta st   " +
                    " join Eligible_Ta et on et.EligibleLdID=st.eligible " +
                    " join Student s  on s.StudentId=et.studentId" +
                    " join [User] u on u.ID=s.UserID " +
                    "where u.ID=1";
                    SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }






            }
        }*/

        /* private void ViewBtn_Click(object sender, EventArgs e)
         {
             string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

             using (SqlConnection SqlConnection = new SqlConnection(connection))
             {
                 string query1 = "Select ta.Type from  Ta_Assesment ta " +
                     " join TeacherAsisitant t on t.Ta_Assesmentid=ta.Ta_Assesmentid" +
                     "  join Student s on s.StudentId=t.StudentId  " +
                     "join [User] u on u.ID=s.UserID" +
                     "  where u.ID=@id";

                 SqlDataAdapter sda1 = new SqlDataAdapter(query1, SqlConnection);
                 sda1.SelectCommand.Parameters.AddWithValue("@id", id);

                 DataTable dtable = new DataTable();
                 sda1.Fill(dtable);


                     string Type = dtable.Rows[0]["Type"].ToString();
                     int courseid = Convert.ToInt32(dtable.Rows[0]["courseid"]);

                 string query5 = "select CourseID,count(StudentID) as total from StudentCourse" +
                     " where CourseID=@courseid group by CourseID";

                 SqlDataAdapter sda5 = new SqlDataAdapter(query5, SqlConnection);
                 sda5.SelectCommand.Parameters.AddWithValue("@courseid", courseid);

                 DataTable dtable5 = new DataTable();
                 sda5.Fill(dtable5);
                 int total = Convert.ToInt32(dtable.Rows[0]["total"]);


                 string query = "";
                     string column = "";

                     switch (Type)
                     {
                         case "p":

                             query = "Select s.StudentId,s.Name,sum(ta.totalAssigments)*250*@total" +
                             " as amount from  Ta_Assesment ta" +
                             "  join TeacherAsisitant t on t.Ta_Assesmentid=ta.Ta_Assesmentid " +
                             " join Student s on s.StudentId=t.StudentId " +
                             "join [User] u on u.ID=s.UserID where u.ID=1" +
                             " group by s.StudentId,s.Name";
                             break;
                         case "h":
                         query = "Select s.StudentId,s.Name,sum(ta.totalAssigments)*190*@total" +
                         " as amount from  Ta_Assesment ta" +
                         "  join TeacherAsisitant t on t.Ta_Assesmentid=ta.Ta_Assesmentid " +
                         " join Student s on s.StudentId=t.StudentId " +
                         "join [User] u on u.ID=s.UserID where u.ID=1" +
                         " group by s.StudentId,s.Name";
                         break;
                     case "m":
                         query = "Select s.StudentId,s.Name,sum(ta.totalAssigments)*150*@total" +
                         " as amount from  Ta_Assesment ta" +
                         "  join TeacherAsisitant t on t.Ta_Assesmentid=ta.Ta_Assesmentid " +
                         " join Student s on s.StudentId=t.StudentId " +
                         "join [User] u on u.ID=s.UserID where u.ID=1" +
                         " group by s.StudentId,s.Name";
                         break;
                         default:
                         MessageBox.Show("Invalid user type.");
                             break;


                 }

                     SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                     sda.SelectCommand.Parameters.AddWithValue("@id", id);
                     sda.SelectCommand.Parameters.AddWithValue("@total", total);

                     DataTable dt = new DataTable();
                     sda.Fill(dt);
                     dataGridView1.DataSource = dt;

             }
         }*/
        private void ViewBtn_Click(object sender, EventArgs e)
        {
            //   string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query1 = "SELECT ta.Type, ta.CourseID FROM Ta_Assesment ta " +
                                "JOIN TeacherAsisitant t ON t.Ta_Assesmentid = ta.Ta_Assesmentid " +
                                "JOIN Student s ON s.StudentId = t.StudentId  " +
                                "JOIN [User] u ON u.ID = s.UserID " +
                                "WHERE u.ID = @id";

                SqlDataAdapter sda1 = new SqlDataAdapter(query1, SqlConnection);
                sda1.SelectCommand.Parameters.AddWithValue("@id", id);

                DataTable dtable = new DataTable();
                sda1.Fill(dtable);

                if (dtable.Rows.Count > 0)
                {
                    string Type = dtable.Rows[0]["Type"].ToString();
                    int courseid = Convert.ToInt32(dtable.Rows[0]["CourseID"]);

                    string query5 = "SELECT CourseID, COUNT(StudentID) AS total FROM StudentCourse " +
                                    "WHERE CourseID = @courseid GROUP BY CourseID";

                    SqlDataAdapter sda5 = new SqlDataAdapter(query5, SqlConnection);
                    sda5.SelectCommand.Parameters.AddWithValue("@courseid", courseid);

                    DataTable dtable5 = new DataTable();
                    sda5.Fill(dtable5);

                    if (dtable5.Rows.Count > 0)
                    {
                        int total = Convert.ToInt32(dtable5.Rows[0]["total"]);

                        string query = "";
                        switch (Type)
                        {
                            case "P":
                                query = "SELECT s.StudentId, s.Name, SUM(ta.totalAssigments) * 250 * @total AS amount " +
                                        "FROM Ta_Assesment ta " +
                                        "JOIN TeacherAsisitant t ON t.Ta_Assesmentid = ta.Ta_Assesmentid " +
                                        "JOIN Student s ON s.StudentId = t.StudentId " +
                                        "JOIN [User] u ON u.ID = s.UserID " +
                                        "WHERE u.ID = @id " +
                                        "GROUP BY s.StudentId, s.Name";
                                break;
                            case "H":
                                query = "SELECT s.StudentId, s.Name, SUM(ta.totalAssigments) * 190 * @total AS amount " +
                                        "FROM Ta_Assesment ta " +
                                        "JOIN TeacherAsisitant t ON t.Ta_Assesmentid = ta.Ta_Assesmentid " +
                                        "JOIN Student s ON s.StudentId = t.StudentId " +
                                        "JOIN [User] u ON u.ID = s.UserID " +
                                        "WHERE u.ID = @id " +
                                        "GROUP BY s.StudentId, s.Name";
                                break;
                            case "M":
                                query = "SELECT s.StudentId, s.Name, SUM(ta.totalAssigments) * 150 * @total AS amount " +
                                        "FROM Ta_Assesment ta " +
                                        "JOIN TeacherAsisitant t ON t.Ta_Assesmentid = ta.Ta_Assesmentid " +
                                        "JOIN Student s ON s.StudentId = t.StudentId " +
                                        "JOIN [User] u ON u.ID = s.UserID " +
                                        "WHERE u.ID = @id " +
                                        "GROUP BY s.StudentId, s.Name";
                                break;
                            default:
                                MessageBox.Show("Invalid user type.");
                                break;
                        }

                        SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                        sda.SelectCommand.Parameters.AddWithValue("@id", id);
                        sda.SelectCommand.Parameters.AddWithValue("@total", total);

                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
                else
                {
                    MessageBox.Show("No data found for the user.");
                }
            }
        }
        private void BackButton_Click(object sender, EventArgs e)
        {
            TAportel taporta = new TAportel();
            taporta.Show();
            this.Hide();
        }

        private void BackButton_Click_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
