﻿namespace Project
{
    partial class manageTA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox7 = new TextBox();
            label9 = new Label();
            label8 = new Label();
            textBox6 = new TextBox();
            label2 = new Label();
            LoginButton = new Button();
            StudentName = new TextBox();
            BackButton = new Button();
            ViewBtn = new Button();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // textBox7
            // 
            textBox7.BackColor = Color.White;
            textBox7.Location = new Point(337, 354);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(212, 23);
            textBox7.TabIndex = 101;
            textBox7.TextAlign = HorizontalAlignment.Center;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.FlatStyle = FlatStyle.Flat;
            label9.Font = new Font("Arial Narrow", 12F);
            label9.ForeColor = SystemColors.Desktop;
            label9.Location = new Point(216, 353);
            label9.Name = "label9";
            label9.Size = new Size(91, 20);
            label9.TabIndex = 100;
            label9.Text = "Course Name";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Arial Narrow", 12F);
            label8.ForeColor = SystemColors.Desktop;
            label8.Location = new Point(216, 312);
            label8.Name = "label8";
            label8.Size = new Size(115, 20);
            label8.TabIndex = 99;
            label8.Text = "No of Assignment";
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.White;
            textBox6.Location = new Point(337, 312);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(212, 23);
            textBox6.TabIndex = 98;
            textBox6.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Arial Narrow", 12F);
            label2.ForeColor = SystemColors.Desktop;
            label2.Location = new Point(216, 275);
            label2.Name = "label2";
            label2.Size = new Size(97, 20);
            label2.TabIndex = 85;
            label2.Text = " Student Name";
            // 
            // LoginButton
            // 
            LoginButton.BackColor = SystemColors.HotTrack;
            LoginButton.ForeColor = SystemColors.ActiveCaptionText;
            LoginButton.Location = new Point(337, 401);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(106, 37);
            LoginButton.TabIndex = 84;
            LoginButton.Text = "Add";
            LoginButton.UseVisualStyleBackColor = false;
            LoginButton.Click += LoginButton_Click;
            // 
            // StudentName
            // 
            StudentName.BackColor = Color.White;
            StudentName.Location = new Point(337, 276);
            StudentName.Name = "StudentName";
            StudentName.Size = new Size(212, 23);
            StudentName.TabIndex = 83;
            StudentName.TextAlign = HorizontalAlignment.Center;
            // 
            // BackButton
            // 
            BackButton.BackColor = SystemColors.ControlDark;
            BackButton.ForeColor = Color.Black;
            BackButton.Location = new Point(24, 38);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(106, 28);
            BackButton.TabIndex = 82;
            BackButton.Text = "Back";
            BackButton.UseVisualStyleBackColor = false;
            BackButton.Click += BackButton_Click_1;
            // 
            // ViewBtn
            // 
            ViewBtn.BackColor = SystemColors.Highlight;
            ViewBtn.ForeColor = SystemColors.Control;
            ViewBtn.Location = new Point(663, 118);
            ViewBtn.Name = "ViewBtn";
            ViewBtn.Size = new Size(106, 28);
            ViewBtn.TabIndex = 81;
            ViewBtn.Text = "View";
            ViewBtn.UseVisualStyleBackColor = false;
            ViewBtn.Click += ViewBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Arial Narrow", 20.25F, FontStyle.Bold);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(224, 72);
            label1.Name = "label1";
            label1.Size = new Size(259, 31);
            label1.TabIndex = 80;
            label1.Text = "Teacher  Asistance List";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(101, 118);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(541, 132);
            dataGridView1.TabIndex = 79;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick_1;
            // 
            // manageTA
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox7);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(textBox6);
            Controls.Add(label2);
            Controls.Add(LoginButton);
            Controls.Add(StudentName);
            Controls.Add(BackButton);
            Controls.Add(ViewBtn);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "manageTA";
            Text = "manageTA";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox7;
        private Label label9;
        private Label label8;
        private TextBox textBox6;
        private Label label2;
        private Button LoginButton;
        private TextBox StudentName;
        private Button BackButton;
        private Button ViewBtn;
        private Label label1;
        private DataGridView dataGridView1;
    }
}