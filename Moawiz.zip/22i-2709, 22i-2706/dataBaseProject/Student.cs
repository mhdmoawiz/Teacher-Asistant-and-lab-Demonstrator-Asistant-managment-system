﻿/*using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void requestForTa_Click(object sender, EventArgs e)
        {
            newrequestsforTA newrequestsforTAForm = new newrequestsforTA();
            newrequestsforTAForm.Show();
            this.Hide();
        }

        private void RequestForLd_Click(object sender, EventArgs e)
        {
            newrequestsforLDA newrequestsforLDAForm = new newrequestsforLDA();
            newrequestsforLDAForm.Show();
            this.Hide();
        }

        private void MangeTA_Click(object sender, EventArgs e)
        {
            TAportel tAportelForm = new TAportel();
            tAportelForm.Show();
            this.Hide();

        }

        private void ManageLd_Click(object sender, EventArgs e)
        {
            LDAportel lDAportelForm = new LDAportel();
            lDAportelForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ConfirmationofLDA confirmationofLDAsForm = new ConfirmationofLDA();
            confirmationofLDAsForm.Show();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ConfirmationofTA confirmationofTAForm = new ConfirmationofTA();
            confirmationofTAForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginPage form1 = new LoginPage();
            form1.Show();
            this.Hide();

        }
    }
}
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{ 
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void requestForTa_Click(object sender, EventArgs e)
        {
            newrequestsforTA newrequestsforTAForm = new newrequestsforTA();
            newrequestsforTAForm.Show();
            this.Hide();
        }

        private void RequestForLd_Click(object sender, EventArgs e)
        {
            newrequestsforLDA newrequestsforLDAForm = new newrequestsforLDA();
            newrequestsforLDAForm.Show();
            this.Hide();
        }

        private void MangeTA_Click(object sender, EventArgs e)
        {
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //   string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select * from TeacherAsisitant t join Student s on s.StudentId=t.StudentId join [User] u on u.ID=s.UserID where u.ID=@id";

                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@id", LoginPage.id);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("you are not a TA");
                }
                else
                {

                    TAportel tAportelForm = new TAportel();
                    tAportelForm.Show();
                    this.Hide();

                }
            }

        }

        private void ManageLd_Click(object sender, EventArgs e)
        {
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select * from LabDemostratorAsisitant t join Student s on s.StudentId=t.StudentId join [User] u on u.ID=s.UserID where u.ID=@id";

                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@id", LoginPage.id);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("you are not a LDA");
                }
                else
                {

                    LDAportel lDAportelForm = new LDAportel();
                    lDAportelForm.Show();
                    this.Hide();

                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ConfirmationofLDA confirmationofLDAsForm = new ConfirmationofLDA();
            confirmationofLDAsForm.Show();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ConfirmationofTA confirmationofTAForm = new ConfirmationofTA();
            confirmationofTAForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginPage form1 = new LoginPage();
            form1.Show();
            this.Hide();

        }
    }
}
