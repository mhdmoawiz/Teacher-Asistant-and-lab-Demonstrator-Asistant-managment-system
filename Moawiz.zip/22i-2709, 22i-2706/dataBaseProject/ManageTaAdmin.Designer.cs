﻿namespace Project
{
    partial class ManageTaAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            label2 = new Label();
            LoginButton = new Button();
            Studentid = new TextBox();
            BackButton = new Button();
            ViewBtn = new Button();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            button3 = new Button();
            textBox2 = new TextBox();
            label5 = new Label();
            textBox4 = new TextBox();
            label3 = new Label();
            label13 = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            label6 = new Label();
            textBox3 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackColor = SystemColors.HotTrack;
            button2.ForeColor = SystemColors.ActiveCaptionText;
            button2.Location = new Point(101, 405);
            button2.Name = "button2";
            button2.Size = new Size(106, 33);
            button2.TabIndex = 69;
            button2.Text = "Update";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.HotTrack;
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(537, 405);
            button1.Name = "button1";
            button1.Size = new Size(106, 33);
            button1.TabIndex = 65;
            button1.Text = "Delete";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Arial Narrow", 12F);
            label2.ForeColor = SystemColors.Desktop;
            label2.Location = new Point(301, 295);
            label2.Name = "label2";
            label2.Size = new Size(70, 20);
            label2.TabIndex = 61;
            label2.Text = "Eligible ID";
            label2.Click += label2_Click;
            // 
            // LoginButton
            // 
            LoginButton.BackColor = SystemColors.HotTrack;
            LoginButton.ForeColor = SystemColors.ActiveCaptionText;
            LoginButton.Location = new Point(301, 405);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(106, 33);
            LoginButton.TabIndex = 60;
            LoginButton.Text = "Add";
            LoginButton.UseVisualStyleBackColor = false;
            LoginButton.Click += LoginButton_Click;
            // 
            // Studentid
            // 
            Studentid.BackColor = Color.White;
            Studentid.Location = new Point(301, 318);
            Studentid.Name = "Studentid";
            Studentid.Size = new Size(105, 23);
            Studentid.TabIndex = 59;
            Studentid.TextAlign = HorizontalAlignment.Center;
            // 
            // BackButton
            // 
            BackButton.BackColor = SystemColors.ControlDark;
            BackButton.ForeColor = Color.Black;
            BackButton.Location = new Point(24, 33);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(106, 28);
            BackButton.TabIndex = 58;
            BackButton.Text = "Back";
            BackButton.UseVisualStyleBackColor = false;
            BackButton.Click += BackButton_Click;
            // 
            // ViewBtn
            // 
            ViewBtn.BackColor = SystemColors.Highlight;
            ViewBtn.ForeColor = SystemColors.Control;
            ViewBtn.Location = new Point(671, 113);
            ViewBtn.Name = "ViewBtn";
            ViewBtn.Size = new Size(106, 28);
            ViewBtn.TabIndex = 57;
            ViewBtn.Text = "View all eligible ";
            ViewBtn.UseVisualStyleBackColor = false;
            ViewBtn.Click += ViewBtn_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Arial Narrow", 20.25F, FontStyle.Bold);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(235, 69);
            label1.Name = "label1";
            label1.Size = new Size(259, 31);
            label1.TabIndex = 56;
            label1.Text = "Teacher  Asistance List";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(101, 113);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(541, 179);
            dataGridView1.TabIndex = 55;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.Highlight;
            button3.ForeColor = SystemColors.Control;
            button3.Location = new Point(671, 156);
            button3.Name = "button3";
            button3.Size = new Size(106, 28);
            button3.TabIndex = 88;
            button3.Text = "View all TA";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.White;
            textBox2.Location = new Point(101, 318);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(105, 23);
            textBox2.TabIndex = 66;
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Arial Narrow", 12F);
            label5.ForeColor = SystemColors.Desktop;
            label5.Location = new Point(101, 343);
            label5.Name = "label5";
            label5.Size = new Size(99, 20);
            label5.TabIndex = 68;
            label5.Text = "New Student Id";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.White;
            textBox4.Location = new Point(101, 366);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(105, 23);
            textBox4.TabIndex = 71;
            textBox4.TextAlign = HorizontalAlignment.Center;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Arial Narrow", 12F);
            label3.ForeColor = SystemColors.Desktop;
            label3.Location = new Point(101, 295);
            label3.Name = "label3";
            label3.Size = new Size(34, 20);
            label3.TabIndex = 84;
            label3.Text = "Taid";
            label3.Click += label3_Click;
            // 
            // label13
            // 
            label13.Location = new Point(0, 0);
            label13.Name = "label13";
            label13.Size = new Size(100, 23);
            label13.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Arial Narrow", 12F);
            label4.ForeColor = SystemColors.Desktop;
            label4.Location = new Point(537, 295);
            label4.Name = "label4";
            label4.Size = new Size(34, 20);
            label4.TabIndex = 92;
            label4.Text = "Taid";
            label4.Click += label4_Click_2;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.White;
            textBox1.Location = new Point(537, 366);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(105, 23);
            textBox1.TabIndex = 91;
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Arial Narrow", 12F);
            label6.ForeColor = SystemColors.Desktop;
            label6.Location = new Point(537, 344);
            label6.Name = "label6";
            label6.Size = new Size(113, 20);
            label6.TabIndex = 90;
            label6.Text = "Ta_assessmentid";
            label6.Click += label6_Click;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.White;
            textBox3.Location = new Point(537, 318);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(105, 23);
            textBox3.TabIndex = 89;
            textBox3.TextAlign = HorizontalAlignment.Center;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // ManageTaAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(textBox1);
            Controls.Add(label6);
            Controls.Add(textBox3);
            Controls.Add(label13);
            Controls.Add(button3);
            Controls.Add(label3);
            Controls.Add(textBox4);
            Controls.Add(button2);
            Controls.Add(label5);
            Controls.Add(textBox2);
            Controls.Add(button1);
            Controls.Add(label2);
            Controls.Add(LoginButton);
            Controls.Add(Studentid);
            Controls.Add(BackButton);
            Controls.Add(ViewBtn);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "ManageTaAdmin";
            Text = "ManageTaAdmin";
            Load += ManageTaAdmin_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button2;
        private Button button1;
        private Label label2;
        private Button LoginButton;
        private TextBox Studentid;
        private Button BackButton;
        private Button ViewBtn;
        private Label label1;
        private DataGridView dataGridView1;
        private Button button3;
        private TextBox textBox2;
        private Label label5;
        private TextBox textBox4;
        private Label label3;
        private Label label13;
        private Label label4;
        private TextBox textBox1;
        private Label label6;
        private TextBox textBox3;
    }
}