﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class manageTA : Form
    {
        int id = LoginPage.id;
        public manageTA()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Faculty facultyForm = new Faculty();
            facultyForm.Show();
            this.Hide();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void BackButton_Click_1(object sender, EventArgs e)
        {
            Faculty f = new Faculty();
            f.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void data()
        {

           //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
         //   string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

            using (SqlConnection connections = new SqlConnection(LoginPage.connection))
            {
                string query = "SELECT DISTINCT s.StudentId,s.Name, c.CourseName, F.Name AS FacultyName, TaS.totalAssigments AS 'Total Assessments' " +
                      "FROM TeacherAsisitant TA " +
                      "INNER JOIN Ta_Assesment Tas ON TA.Ta_Assesmentid = Tas.Ta_Assesmentid " +
                      "INNER JOIN Student S ON S.StudentId = Ta.StudentId " +
                      "INNER JOIN Courses c ON c.CourseID = Tas.courseid " +
                      "INNER JOIN Faculty f ON F.FacultyId = Tas.facultyid " +
                      "INNER JOIN [User] u ON u.ID = F.UserID " +
                      "where u.ID = @Id";


                // Now you can use the 'queryString' variable wherever you need the SQL query as a string.

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connections))
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@Id", id);
                    DataTable dataTable = new DataTable();

                    try
                    {

                        connections.Open();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }

                }
            }

        }

        /* private void LoginButton_Click(object sender, EventArgs e)
         {
             string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
             string Studentname = StudentName.Text;
             string coursename = textBox7.Text;
             string assesment = textBox6.Text;

             if (string.IsNullOrWhiteSpace(Studentname) || string.IsNullOrWhiteSpace(coursename) || string.IsNullOrWhiteSpace(assesment))

             {

                 using (SqlConnection SqlConnection = new SqlConnection(connection))
                 {
                     string query = "SELECT Tas.Ta_Assesmentid FROM TeacherAsisitant tA " +
                           "INNER JOIN Student s ON s.StudentId = Ta.StudentId " +
                           "INNER JOIN Ta_Assesment TAS ON Tas.Ta_Assesmentid = tA.Ta_Assesmentid " +
                           "INNER JOIN Courses c ON c.CourseID = TAS.courseid " +
                           "WHERE c.CourseName = @CN AND s.Name = @SN";


                     SqlDataAdapter sd1 = new SqlDataAdapter(query, SqlConnection);
                     sd1.SelectCommand.Parameters.AddWithValue("@SN", StudentName);
                     sd1.SelectCommand.Parameters.AddWithValue("@CN", coursename);
                     DataTable dtable1 = new DataTable();
                     sd1.Fill(dtable1);

                     if (dtable1.Rows.Count > 0)
                     {
                         int TaassementId = Convert.ToInt32(dtable1.Rows[0]["Ta_Assesmentid"]);


                         if (int.TryParse(assesment, out int assessmentInt))
                         {

                             string updateQuery = "UPDATE Ta_Assesment " +
                          "SET totalAssigments =  @asses" +
                          "WHERE Ta_Assesmentid = @id";


                             using (SqlCommand cmd = new SqlCommand(updateQuery, SqlConnection))
                             {
                                 cmd.Parameters.AddWithValue("@id", TaassementId);
                                 cmd.Parameters.AddWithValue("@asses", assessmentInt);
                                 try
                                 {
                                     SqlConnection.Open();
                                     cmd.ExecuteNonQuery();
                                     MessageBox.Show(" assesment updated succesfully ");
                                 }
                                 catch (Exception ex)
                                 {
                                     MessageBox.Show("Error: " + ex.Message);
                                 }
                             }





                         }
                         else
                         {
                             MessageBox.Show("assigment value can be integer ");

                         }


                     }
                     else
                     {
                         MessageBox.Show("No  TA found.");
                     }
                 }
             }
             else
             {
                 MessageBox.Show("EmptyBoxes");
             }

         }*/



        private void LoginButton_Click(object sender, EventArgs e)
        {
             //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
         //   string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            string studentName = StudentName.Text;
            string courseName = textBox7.Text;
            string assessment = textBox6.Text;

            if (string.IsNullOrWhiteSpace(studentName) || string.IsNullOrWhiteSpace(courseName) || string.IsNullOrWhiteSpace(assessment))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            if (int.TryParse(assessment, out int assessmentInt))
            {
                using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
                {
                    string query = "SELECT Tas.Ta_Assesmentid FROM TeacherAsisitant tA " +
                                   "INNER JOIN Student s ON s.StudentId = Ta.StudentId " +
                                   "INNER JOIN Ta_Assesment TAS ON Tas.Ta_Assesmentid = tA.Ta_Assesmentid " +
                                   "INNER JOIN Courses c ON c.CourseID = TAS.courseid " +
                                   "WHERE c.CourseName = @CN AND s.Name = @SN";

                    SqlDataAdapter sd1 = new SqlDataAdapter(query, SqlConnection);
                    sd1.SelectCommand.Parameters.AddWithValue("@SN", studentName);
                    sd1.SelectCommand.Parameters.AddWithValue("@CN", courseName);
                    DataTable dtable1 = new DataTable();
                    sd1.Fill(dtable1);

                    if (dtable1.Rows.Count > 0)
                    {
                        int TaAssessmentId = Convert.ToInt32(dtable1.Rows[0]["Ta_Assesmentid"]);

                        string updateQuery = "UPDATE Ta_Assesment " +
                                             "SET totalAssigments = @asses " +
                                             "WHERE Ta_Assesmentid = @id";

                        using (SqlCommand cmd = new SqlCommand(updateQuery, SqlConnection))
                        {
                            cmd.Parameters.AddWithValue("@id", TaAssessmentId);
                            cmd.Parameters.AddWithValue("@asses", assessmentInt);
                            try
                            {
                                SqlConnection.Open();
                                cmd.ExecuteNonQuery();
                                MessageBox.Show("Assessment updated successfully.");
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error: " + ex.Message);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("No TA found for the specified student and course.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Assessment value must be an integer.");
            }
        }


        private void ViewBtn_Click(object sender, EventArgs e)
        {
            data();
        }
    }
}

