﻿namespace Project
{
    partial class LoginPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Password = new TextBox();
            LoginButton = new Button();
            login = new TextBox();
            label1 = new Label();
            userid = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // Password
            // 
            Password.BackColor = Color.White;
            Password.Location = new Point(276, 237);
            Password.Name = "Password";
            Password.Size = new Size(191, 21);
            Password.TabIndex = 53;
            Password.TextAlign = HorizontalAlignment.Center;
            Password.TextChanged += password_TextChanged;
            // 
            // LoginButton
            // 
            LoginButton.BackColor = SystemColors.HotTrack;
            LoginButton.ForeColor = SystemColors.ActiveCaptionText;
            LoginButton.Location = new Point(276, 296);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(108, 35);
            LoginButton.TabIndex = 52;
            LoginButton.Text = "Login";
            LoginButton.UseVisualStyleBackColor = false;
            LoginButton.Click += LoginButton_Click;
            // 
            // login
            // 
            login.BackColor = Color.White;
            login.Location = new Point(276, 187);
            login.Name = "login";
            login.Size = new Size(191, 21);
            login.TabIndex = 51;
            login.TextAlign = HorizontalAlignment.Center;
            login.TextChanged += login_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Calibri", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Highlight;
            label1.Location = new Point(64, 94);
            label1.Name = "label1";
            label1.Size = new Size(546, 42);
            label1.TabIndex = 50;
            label1.Text = "Fast TA and Ld Management system ";
            label1.Click += label1_Click;
            // 
            // userid
            // 
            userid.AutoSize = true;
            userid.FlatStyle = FlatStyle.Flat;
            userid.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            userid.ForeColor = SystemColors.ControlText;
            userid.Location = new Point(189, 187);
            userid.Name = "userid";
            userid.Size = new Size(50, 17);
            userid.TabIndex = 54;
            userid.Text = "UserId";
            userid.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.Desktop;
            label3.Location = new Point(189, 237);
            label3.Name = "label3";
            label3.Size = new Size(74, 17);
            label3.TabIndex = 55;
            label3.Text = "Password";
            // 
            // LoginPage
            // 
            AutoScaleDimensions = new SizeF(6F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(657, 503);
            Controls.Add(label3);
            Controls.Add(userid);
            Controls.Add(Password);
            Controls.Add(LoginButton);
            Controls.Add(login);
            Controls.Add(label1);
            Font = new Font("Arial Narrow", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "LoginPage";
            Text = "LoginPage";
            Load += LoginPage_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox Password;
        private Button LoginButton;
        private TextBox login;
        private Label label1;
        private Label userid;
        private Label label3;
    }
}