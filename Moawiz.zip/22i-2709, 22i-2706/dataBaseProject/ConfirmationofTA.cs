﻿/*using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ConfirmationofTA : Form
    {
        public ConfirmationofTA()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConfirmationofTA confirmationofTA = new ConfirmationofTA();
            confirmationofTA.Show();
            this.Hide();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }
    }
}
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ConfirmationofTA : Form
    {
        public ConfirmationofTA()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(Studentid.Text))
            {
                call();
                ConfirmationofTA confirmationofTA = new ConfirmationofTA();
                confirmationofTA.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter confirmation Request ID.");
            }
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Studentid.Text))
            {
                call();
                Student studentForm = new Student();
                studentForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter confirmation Request ID.");
            }
        }

        private void ViewBtn_Click(object sender, EventArgs e)
        {



        }

        private void button2_Click(object sender, EventArgs e)
        {


        }

        private void Studentid_TextChanged(object sender, EventArgs e)
        {

        }

        private void call()
        {
            int selectedid = Convert.ToInt32(Studentid.Text);
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            // string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "SELECT te.FacultyId, t.Type, t.CourseID, et.studentId, et.EligibleLdID, t.TaRequestID " +
                               "FROM SelectedTa st " +
                               "JOIN Eligible_Ta et ON et.EligibleLdID = st.eligibleid " +
                               "JOIN TaRequest t ON t.TaRequestID = et.TaRequestid " +
                               "JOIN Teacher te ON te.TeacherId = t.Teacher " +
                               "WHERE st.SeletedTaId = @SelectedTaid";

                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@SelectedTaid", selectedid);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    int courseid = Convert.ToInt32(dt.Rows[0]["CourseID"]);
                    int facultyid = Convert.ToInt32(dt.Rows[0]["FacultyId"]);
                    string type = dt.Rows[0]["Type"].ToString();
                    int studentid = Convert.ToInt32(dt.Rows[0]["studentId"]);
                    int TaRequestid = Convert.ToInt32(dt.Rows[0]["TaRequestID"]);
                    int EligibleLdID = Convert.ToInt32(dt.Rows[0]["EligibleLdID"]);
                    int totalAssigments = 0;

                    // Insert into Ta_Assesment table
                    string insertTaAssesmentQuery = "INSERT INTO Ta_Assesment (courseid, facultyid, totalAssigments, Type) " +
                                                     "VALUES (@courseid, @facultyid, @totalAssigments, @Type)";
                    SqlCommand command = new SqlCommand(insertTaAssesmentQuery, SqlConnection);
                    command.Parameters.AddWithValue("@courseid", courseid);
                    command.Parameters.AddWithValue("@facultyid", facultyid);
                    command.Parameters.AddWithValue("@totalAssigments", totalAssigments);
                    command.Parameters.AddWithValue("@Type", type);

                    SqlConnection.Open();
                    command.ExecuteNonQuery();

                    // Get Ta_Assesmentid
                    string selectTaAssesmentIdQuery = "SELECT Ta_Assesmentid FROM Ta_Assesment WHERE courseid = @courseid AND facultyid = @facultyid";
                    SqlDataAdapter sda1 = new SqlDataAdapter(selectTaAssesmentIdQuery, SqlConnection);
                    sda1.SelectCommand.Parameters.AddWithValue("@courseid", courseid);
                    sda1.SelectCommand.Parameters.AddWithValue("@facultyid", facultyid);
                    DataTable dt1 = new DataTable();
                    sda1.Fill(dt1);
                    int Ta_Assesmentid = Convert.ToInt32(dt1.Rows[0]["Ta_Assesmentid"]);

                    // Insert into TeacherAssistant table
                    string insertTeacherAssistantQuery = "INSERT INTO TeacherAsisitant (Ta_Assesmentid, studentid) " +
                                                          "VALUES (@Ta_Assesmentid, @studentid)";
                    SqlCommand command1 = new SqlCommand(insertTeacherAssistantQuery, SqlConnection);
                    command1.Parameters.AddWithValue("@Ta_Assesmentid", Ta_Assesmentid);
                    command1.Parameters.AddWithValue("@studentid", studentid);
                    command1.ExecuteNonQuery();

                    // Delete from SelectedTa table
                    string deleteSelectedTaQuery = "DELETE FROM SelectedTa WHERE SeletedTaId = @selectedid";
                    SqlCommand command2 = new SqlCommand(deleteSelectedTaQuery, SqlConnection);
                    command2.Parameters.AddWithValue("@selectedid", selectedid);
                    command2.ExecuteNonQuery();

                    // Delete from Eligible_Ta table
                    string deleteEligibleTaQuery = "DELETE FROM Eligible_Ta WHERE EligibleLdID = @EligibleLdID";
                    SqlCommand command3 = new SqlCommand(deleteEligibleTaQuery, SqlConnection);
                    command3.Parameters.AddWithValue("@EligibleLdID", EligibleLdID);
                    command3.ExecuteNonQuery();

                    // Delete from TaRequest table
                    string deleteTaRequestQuery = "DELETE FROM TaRequest WHERE TaRequestID = @TaRequestid";
                    SqlCommand command4 = new SqlCommand(deleteTaRequestQuery, SqlConnection);
                    command4.Parameters.AddWithValue("@TaRequestid", TaRequestid);
                    command4.ExecuteNonQuery();

                    SqlConnection.Close();

                    MessageBox.Show("Congratulations for becoming TA!");
                }
                else
                {
                    MessageBox.Show("Student is not selected for TA");
                }
            }
        }

        private void ViewBtn_Click_1(object sender, EventArgs e)
        {
                     //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //            string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "SELECT s.SeletedTaId, c.CourseName, f.Name, sch.Data, sch.StartingTime, sch.EndingTime FROM SelectedTa s" +
                " JOIN Eligible_Ta et ON et.EligibleLdID = s.eligibleid" +
                " JOIN TaRequest tr ON tr.TaRequestID = et.TaRequestid" +
                " JOIN Courses c ON c.CourseID = tr.CourseID" +
                " JOIN Schedule sch ON sch.CourseID = c.CourseID" +
                " JOIN Teacher t ON t.TeacherId = tr.Teacher" +
                " JOIN Faculty f ON f.FacultyId = t.FacultyId" +
                " JOIN Student st ON st.StudentId = et.studentId" +
                " JOIN [User] u ON u.ID = st.UserID" +
                " WHERE u.ID = @id;";

                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@id", LoginPage.id);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("you are not selected for TA");
                }
                else
                {
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            // string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "SELECT s.Name AS StudentName, c.CourseName, sch.Data AS Day," +
                 "  sch.StartingTime, sch.EndingTime FROM [User] u" +
                 " JOIN Student s ON u.ID = s.UserID " +
                 " JOIN StudentCourse sc ON s.StudentId = sc.StudentID " +
                 " JOIN Schedule sch ON sc.CourseID = sch.CourseID " +
                 " JOIN Courses c ON sc.CourseID = c.CourseID" +
                 " WHERE u.ID = @id;";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@id", LoginPage.id);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView2.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
