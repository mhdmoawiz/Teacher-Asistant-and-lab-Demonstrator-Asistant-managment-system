﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Project
{

    public partial class Faculty : Form
    {
        int id = LoginPage.id;
        public Faculty()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginPage form1 = new LoginPage();
            form1.Show();
            this.Hide();

        }

        private void requestForTa_Click(object sender, EventArgs e)
        {
            //    string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select T.FacultyId\r\nfrom [user] u \r\ninner join Faculty f on u.ID= f.UserID \r\ninner join Teacher T on f.FacultyId = T.FacultyId\r\nwhere u.id = @Taid;";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@Taid", id);


                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                if (dtable.Rows.Count == 0)
                {
                    MessageBox.Show("you are not Teacher  in any course  ");
                }
                else
                {
                    RequestforTA requestforTAForm = new RequestforTA();
                    requestforTAForm.Show();
                    this.Hide();
                }
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            // string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
           // string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select T.FacultyId\r\nfrom [user] u \r\ninner join Faculty f on u.ID= f.UserID \r\ninner join Teacher T on f.FacultyId = T.FacultyId\r\nwhere u.id = @Taid;";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@Taid", id);


                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                if (dtable.Rows.Count == 0)
                {
                    MessageBox.Show("you are not Teacher  in any course  ");
                }
                else
                {
                    HireTA hireTAForm = new HireTA();
                    hireTAForm.Show();
                    this.Hide();
                }
            }


        }

        private void RequestForLd_Click(object sender, EventArgs e)
        {
            //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select ld.LabDemostratorID\r\nfrom [user] u \r\ninner join Faculty f on u.ID= f.UserID \r\ninner join LabDemostrator ld on f.FacultyId = ld.FactaryID\r\nwhere u.id = @Ldid;";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@Ldid", id);


                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                if (dtable.Rows.Count == 0)
                {
                    MessageBox.Show("you are not lab demostrator in any course  ");
                }
                else
                {
                    Ldarequestsfrom ldarequestsfromForm = new Ldarequestsfrom();
                    ldarequestsfromForm.Show();
                    this.Hide();
                }
            }
        }
        // null
        private void MangeTA_Click(object sender, EventArgs e)
        {

        }

        private void MangeTA_Click_1(object sender, EventArgs e)
        {


            //   string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select T.FacultyId\r\nfrom [user] u \r\ninner join Faculty f on u.ID= f.UserID \r\ninner join Teacher T on f.FacultyId = T.FacultyId\r\nwhere u.id = @Taid;";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@Taid", id);


                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                if (dtable.Rows.Count == 0)
                {
                    MessageBox.Show("you are not Teacher  in any course  ");
                }
                else
                {
                    manageTA manageTAForm = new manageTA();
                    manageTAForm.Show();
                    this.Hide();
                }
            }


        }

        private void ManageLd_Click(object sender, EventArgs e)
        {
            //    string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select ld.LabDemostratorID\r\nfrom [user] u \r\ninner join Faculty f on u.ID= f.UserID \r\ninner join LabDemostrator ld on f.FacultyId = ld.FactaryID\r\nwhere u.id = @Ldid;";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@Ldid", id);


                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                if (dtable.Rows.Count == 0)
                {
                    MessageBox.Show("you are not lab demostrator in any course  ");
                }
                else
                {

                    ManagaeLDA manageLDAForm = new ManagaeLDA();
                    manageLDAForm.Show();
                    this.Hide();
                }
            }




        }

        private void button2_Click(object sender, EventArgs e)
        {
            //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
           // string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select ld.LabDemostratorID\r\nfrom [user] u \r\ninner join Faculty f on u.ID= f.UserID \r\ninner join LabDemostrator ld on f.FacultyId = ld.FactaryID\r\nwhere u.id = @Ldid;";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@Ldid", id);


                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                if (dtable.Rows.Count == 0)
                {
                    MessageBox.Show("you are not lab demostrator in any course  ");
                }
                else
                {

                    hireLDA hireLDAsForm = new hireLDA();
                    hireLDAsForm.Show();
                    this.Hide();
                }
            }
        }

        private void Dashboard_Click(object sender, EventArgs e)
        {

        }
    }
}
