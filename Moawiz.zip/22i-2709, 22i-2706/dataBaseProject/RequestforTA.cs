﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{

    public partial class RequestforTA : Form
    {
        /* LOGIN login = new LOGIN(); */
        int id = LoginPage.id;
        public RequestforTA()
        {
            InitializeComponent();
            data();
        }

        private void RequestforTA_Load(object sender, EventArgs e)
        {

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Faculty facultyForm = new Faculty();
            facultyForm.Show();
            this.Hide();
        }

        private void Studentid_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void data()
        {

            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

            using (SqlConnection connections = new SqlConnection(LoginPage.connection))
            {
                string query = "select distinct  c.CourseName , f.Name , u.ID from Teacher   T inner join" +
                    " Faculty f  on t.FacultyId  = f.FacultyId or t.FacultyId = f.FacultyId " +
                    "inner join CourseFaculty cf on cf.FacultyID = f.FacultyId inner join [user] u on u.ID = f.UserID " +
                    "inner join Courses c on c.CourseID = cf.CourseID where u.ID = @Id";
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connections))
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@Id", id);
                    DataTable dataTable = new DataTable();

                    try
                    {

                        connections.Open();
                        adapter.Fill(dataTable);
                        dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
                        dataGridView1.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }

                }
            }

        }
        private void LoginButton_Click(object sender, EventArgs e)
        {
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //     string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            int courseId;
            int facultyid;
            int Tid;

            string coursename = CourseName.Text;
            string facultyname = FacultyName.Text;
            string Type = type.Text;

            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "SELECT CourseID FROM Courses WHERE CourseName = @Coursename;";
                SqlDataAdapter sd1 = new SqlDataAdapter(query, SqlConnection);
                sd1.SelectCommand.Parameters.AddWithValue("@Coursename", coursename);
                DataTable dtable1 = new DataTable();
                sd1.Fill(dtable1);

                string query1 = "SELECT FacultyId FROM Faculty WHERE Name = @facultyname;";
                SqlDataAdapter sd2 = new SqlDataAdapter(query1, SqlConnection);
                sd2.SelectCommand.Parameters.AddWithValue("@facultyname", facultyname);
                DataTable dtable2 = new DataTable();
                sd2.Fill(dtable2);

                // Check if both course and faculty exist
                if (dtable1.Rows.Count > 0 && dtable2.Rows.Count > 0)
                {
                    courseId = Convert.ToInt32(dtable1.Rows[0]["CourseID"].ToString());
                    facultyid = Convert.ToInt32(dtable2.Rows[0]["FacultyId"].ToString());

                    // Validate course type
                    if (Type.Length == 1 && (Type == "P" || Type == "M" || Type == "H"))
                    {
                        string query2 = "SELECT DISTINCT t.TeacherId FROM Faculty f " +
                                        "INNER JOIN Teacher t ON f.FacultyId = t.FacultyId " +
                                        "INNER JOIN CourseFaculty cf ON cf.FacultyID = f.FacultyId " +
                                        "INNER JOIN Courses c ON c.CourseID = cf.CourseID " +
                                        "WHERE c.CourseID = @CourseID AND T.FacultyId = @FacultyID;";

                        SqlDataAdapter sd3 = new SqlDataAdapter(query2, SqlConnection);
                        sd3.SelectCommand.Parameters.AddWithValue("@CourseID", courseId);
                        sd3.SelectCommand.Parameters.AddWithValue("@FacultyID", facultyid);
                        DataTable dtable3 = new DataTable();
                        sd3.Fill(dtable3);

                        // If the teacher is associated with the course and no existing request is found
                        if (dtable3.Rows.Count > 0)
                        {
                            Tid = Convert.ToInt32(dtable3.Rows[0]["TeacherId"]);


                            String query4 = "select TaRequestID from TaRequest where CourseID = @CourseID and Teacher = @TID;";

                            SqlDataAdapter sd4 = new SqlDataAdapter(query4, SqlConnection);
                            sd4.SelectCommand.Parameters.AddWithValue("@CourseID", courseId);
                            sd4.SelectCommand.Parameters.AddWithValue("@TID", Tid);
                            DataTable dtable4 = new DataTable();
                            sd4.Fill(dtable4);




                            if (dtable4.Rows.Count == 0)
                            {




                                string query5 = "INSERT INTO TaRequest (CourseID, Teacher, Type) VALUES (@CourseID, @TeacherID, @Type);";
                                SqlCommand cmd = new SqlCommand(query5, SqlConnection);
                                cmd.Parameters.AddWithValue("@CourseID", courseId);
                                cmd.Parameters.AddWithValue("@TeacherID", Tid);
                                cmd.Parameters.AddWithValue("@Type", Type);
                                SqlConnection.Open();
                                cmd.ExecuteNonQuery();
                                SqlConnection.Close();
                                MessageBox.Show("Request added successfully.");
                            }
                            else
                            {
                                MessageBox.Show("You have already add request ");
                            }
                        }
                        else
                        {
                            MessageBox.Show("You are not assigned to teach this course.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid course type. It should be P, M, or H.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid course name or faculty name.");
                }

                CourseName.Clear();
                FacultyName.Clear();
                type.Clear();

            }
        }



        private void type_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
        }
    }
}
