﻿/*using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class newrequestsforTA : Form
    {
        public newrequestsforTA()
        {
            InitializeComponent();
        }

        private void newrequestsforTA_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            newrequestsforTA newrequestsforTAForm = new newrequestsforTA();
            newrequestsforTAForm.Show();
            this.Hide();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();    
            studentForm.Show();
            this.Hide();
        }
    }
}
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Project
{
    public partial class newrequestsforTA : Form
    {
        int id = LoginPage.id;
        int TAid;
        public newrequestsforTA()
        {
            InitializeComponent();
        }

        private void newrequestsforTA_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Studentid.Text))
            {
                TAid = Convert.ToInt32(Studentid.Text);
                call();
                newrequestsforTA newrequestsforTAForm = new newrequestsforTA();
                newrequestsforTAForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter TA Request ID.");
            }
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Studentid.Text))
            {
                TAid = Convert.ToInt32(Studentid.Text);
                call();
                Student studentForm = new Student();
                studentForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter TA Request ID.");
            }


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        /* private void ViewBtn_Click(object sender, EventArgs e)
         {
             string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
             using (SqlConnection SqlConnection = new SqlConnection(connection))
             {
                 string query = "select ta.TaRequestID,c.CourseName,f.Name,ta.Type" +
                     " from TaRequest ta" +
                     "join Teacher t on t.TeacherId=ta.Teacher" +
                     "join Courses c on c.CourseID=ta.CourseID" +
                     "join Faculty f on f.FacultyId=t.FacultyId";
                 SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                 DataTable dt = new DataTable();
                 sda.Fill(dt);
                 dataGridView1.DataSource = dt;

             }
         }
        */
        private void ViewBtn_Click(object sender, EventArgs e)
        {

        }

        private void Studentid_TextChanged(object sender, EventArgs e)
        {



        }

        //create the function that will run the query to insert the student id and TAid in the eligible table
        /*private void call( )
        {
            string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //first run a quurey to get cousre id from TAid then run qurrey to check wheather student id is in the Studied table or not then run a qurrey to check student cgpa is greater than 3.0 or not then insert it in the Eligible table
            using (SqlConnection SqlConnection = new SqlConnection(connection))
            {
                string query = "select CourseId from TaRequest where TaRequestID = @TAid;";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@TAid", TAid);
                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                int courseId = Convert.ToInt32(dtable.Rows[0]["CourseId"]);

                string query1 = "select * from StudiedCourse sc" +
                " join Student s on s.StudentId=sc.StudentID " +
                "join [User] u on u.ID=s.UserID join " +
                "Transcript t on t.StudentID=s.StudentId where u.ID=@id and" +
                " sc.CourseID=@courseId  and t.CGPA>3.0";
                //run the query1 and check if the student is in the studied course or not and cgpa is greater than 3.0 or not then insert it in the eligible table
                SqlDataAdapter sda1 = new SqlDataAdapter(query1, SqlConnection);
                sda1.SelectCommand.Parameters.AddWithValue("@id", id);
                sda1.SelectCommand.Parameters.AddWithValue("@courseId", courseId);
                DataTable dtable1 = new DataTable();
                sda1.Fill(dtable1);
                if (dtable1.Rows.Count == 0)
                {
                    MessageBox.Show("Student is not eligible for TA");
                }
                else
                {
                    string query3 = "select s.StudentId from Student s join [User] u on u.id=s.userId where u.id = @id";
                    SqlDataAdapter sda3 = new SqlDataAdapter(query3, SqlConnection);
                    sda3.SelectCommand.Parameters.AddWithValue("@id", id);
                    DataTable dtable3 = new DataTable();
                    sda3.Fill(dtable3);
                    int StudentId = Convert.ToInt32(dtable3.Rows[0]["StudentId"]);




                    string query2 = "insert into Eligible_Ta values(@studentId,@TaRequestid)";
                    SqlDataAdapter sda2 = new SqlDataAdapter(query2, SqlConnection);
                    sda2.SelectCommand.Parameters.AddWithValue("@studentId", StudentId);
                    sda2.SelectCommand.Parameters.AddWithValue("@TaRequestid", TAid);
                    sda2.SelectCommand.ExecuteNonQuery();

                    MessageBox.Show("Student is eligible for TA");
                }





            }
        }*/
        /*private void call()
        {
            string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(connection))
            {
                //write a query to get TA requestid from eligible TA table
                string query5 = "select * from Eligible_Ta where EligibleLdID=@TAid";
                SqlDataAdapter sda5 = new SqlDataAdapter(query5, SqlConnection);
                sda5.SelectCommand.Parameters.AddWithValue("@TAid", TAid);
                DataTable dtable5 = new DataTable();
                sda5.Fill(dtable5);
                if (dtable5.Rows.Count > 0)
                {
                    MessageBox.Show("Student is already eligible for TA");
                }


                else if (){ 
                         string query = "select CourseId from TaRequest where TaRequestID = @TAid;";
                         SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                         sda.SelectCommand.Parameters.AddWithValue("@TAid", TAid);
                         DataTable dtable = new DataTable();
                         sda.Fill(dtable);
                         int courseId = Convert.ToInt32(dtable.Rows[0]["CourseId"]);

                          string query1 = "select * from StudiedCourse sc" +
                            " join Student s on s.StudentId=sc.StudentID " +
                            " join [User] u on u.ID=s.UserID join " +
                            " Transcript t on t.StudentID=s.StudentId where u.ID=@id and" +
                            " sc.CourseID=@courseId  and t.CGPA>3.0";
                          SqlDataAdapter sda1 = new SqlDataAdapter(query1, SqlConnection);
                          sda1.SelectCommand.Parameters.AddWithValue("@id", id);
                          sda1.SelectCommand.Parameters.AddWithValue("@courseId", courseId);
                          DataTable dtable1 = new DataTable();
                          sda1.Fill(dtable1);
                         if (dtable1.Rows.Count == 0)
                         {
                             MessageBox.Show("Student is not eligible for TA");
                         }
                         else
                         {
                    string query3 = "select s.StudentId from Student s join [User] u on u.id=s.userId where u.id = @id";
                    SqlDataAdapter sda3 = new SqlDataAdapter(query3, SqlConnection);
                    sda3.SelectCommand.Parameters.AddWithValue("@id", id);
                    DataTable dtable3 = new DataTable();
                    sda3.Fill(dtable3);
                    int StudentId = Convert.ToInt32(dtable3.Rows[0]["StudentId"]);

                    string query2 = "insert into Eligible_Ta values(@studentId,@TaRequestid)";
                    SqlCommand command = new SqlCommand(query2, SqlConnection);
                    command.Parameters.AddWithValue("@studentId", StudentId);
                    command.Parameters.AddWithValue("@TaRequestid", TAid);

                    SqlConnection.Open();
                    command.ExecuteNonQuery();
                    SqlConnection.Close();

                    MessageBox.Show("Student is eligible for TA");
                         }

                }
            }
        }*/
        private void call()
        {
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

            //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query5 = "select * from Eligible_Ta et join Student s on s.StudentId=et.studentId join [User] u on u.ID=s.UserID where et.TaRequestid =@TAid and u.ID=@id";
                SqlDataAdapter sda5 = new SqlDataAdapter(query5, SqlConnection);
                sda5.SelectCommand.Parameters.AddWithValue("@TAid", TAid);
                sda5.SelectCommand.Parameters.AddWithValue("@id", id);
                DataTable dtable5 = new DataTable();
                sda5.Fill(dtable5);

                if (dtable5.Rows.Count > 0)
                {
                    MessageBox.Show("Student is already eligible for TA and added");
                }
                else
                {
                    string query = "select CourseId from TaRequest where TaRequestID = @TAid;";
                    SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                    sda.SelectCommand.Parameters.AddWithValue("@TAid", TAid);
                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);
                    int courseId = Convert.ToInt32(dtable.Rows[0]["CourseId"]);

                    string query1 = "select * from StudiedCourse sc " +
                                    "join Student s on s.StudentId = sc.StudentID " +
                                    "join [User] u on u.ID = s.UserID join " +
                                    "Transcript t on t.StudentID = s.StudentId " +
                                    "where u.ID = @id and sc.CourseID = @courseId and t.CGPA > 2.0";
                    SqlDataAdapter sda1 = new SqlDataAdapter(query1, SqlConnection);
                    sda1.SelectCommand.Parameters.AddWithValue("@id", id);
                    sda1.SelectCommand.Parameters.AddWithValue("@courseId", courseId);
                    DataTable dtable1 = new DataTable();
                    sda1.Fill(dtable1);

                    if (dtable1.Rows.Count == 0)
                    {
                        MessageBox.Show("Student is not eligible for TA");
                    }
                    else
                    {
                        int studentId = Convert.ToInt32(dtable1.Rows[0]["StudentId"]);
                        string insertQuery = "insert into Eligible_Ta values(@studentId, @TaRequestid)";
                        SqlCommand command = new SqlCommand(insertQuery, SqlConnection);
                        command.Parameters.AddWithValue("@studentId", studentId);
                        command.Parameters.AddWithValue("@TaRequestid", TAid);

                        SqlConnection.Open();
                        command.ExecuteNonQuery();
                        SqlConnection.Close();

                        MessageBox.Show("Student is eligible for TA and successfully added");
                    }
                }
            }
        }

        private void ViewBtn_Click_1(object sender, EventArgs e)
        {
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select ta.TaRequestID,c.CourseName,f.Name,ta.Type " +
                                "from TaRequest ta " +
                                "join Teacher t on t.TeacherId = ta.Teacher " +
                                "join Courses c on c.CourseID = ta.CourseID " +
                                "join Faculty f on f.FacultyId = t.FacultyId";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void Studentid_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
