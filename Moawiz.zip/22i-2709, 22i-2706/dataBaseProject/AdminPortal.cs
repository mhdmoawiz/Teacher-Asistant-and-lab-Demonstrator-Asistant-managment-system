﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class AdminPortal : Form
    {
        public AdminPortal()
        {
            InitializeComponent();
        }

        private void Dashboard_Click(object sender, EventArgs e)
        {

        }

        private void AdminPortal_Load(object sender, EventArgs e)
        {

        }

        private void MangeTA_Click(object sender, EventArgs e)
        {
            ManageTaAdmin manageTaAdmin = new ManageTaAdmin();
            manageTaAdmin.Show();
            this.Hide();
        }

        private void ManageLd_Click(object sender, EventArgs e)
        {
            ManageLdAdmin manageLdAdmin = new ManageLdAdmin();
            manageLdAdmin.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginPage loginPage = new LoginPage();
            loginPage.Show();
            this.Hide();
        }
    }
}
