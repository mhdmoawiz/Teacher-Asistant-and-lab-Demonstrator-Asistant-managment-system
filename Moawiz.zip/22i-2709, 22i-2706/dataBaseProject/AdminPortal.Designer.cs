﻿namespace Project
{
    partial class AdminPortal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            ManageLd = new Button();
            MangeTA = new Button();
            Dashboard = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Beige;
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(89, 385);
            button1.Name = "button1";
            button1.Size = new Size(108, 32);
            button1.TabIndex = 26;
            button1.Text = "Sign Out";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // ManageLd
            // 
            ManageLd.BackColor = SystemColors.Highlight;
            ManageLd.ForeColor = SystemColors.ButtonHighlight;
            ManageLd.Location = new Point(318, 200);
            ManageLd.Name = "ManageLd";
            ManageLd.Size = new Size(213, 32);
            ManageLd.TabIndex = 25;
            ManageLd.Text = "Manage LDA";
            ManageLd.UseVisualStyleBackColor = false;
            ManageLd.Click += ManageLd_Click;
            // 
            // MangeTA
            // 
            MangeTA.BackColor = SystemColors.Highlight;
            MangeTA.ForeColor = SystemColors.ButtonHighlight;
            MangeTA.Location = new Point(318, 133);
            MangeTA.Name = "MangeTA";
            MangeTA.Size = new Size(213, 32);
            MangeTA.TabIndex = 24;
            MangeTA.Text = "Manage TA";
            MangeTA.UseVisualStyleBackColor = false;
            MangeTA.Click += MangeTA_Click;
            // 
            // Dashboard
            // 
            Dashboard.AutoSize = true;
            Dashboard.Font = new Font("Arial Narrow", 26.25F, FontStyle.Bold);
            Dashboard.ForeColor = SystemColors.Desktop;
            Dashboard.Location = new Point(190, 39);
            Dashboard.Name = "Dashboard";
            Dashboard.Size = new Size(456, 42);
            Dashboard.TabIndex = 21;
            Dashboard.Text = "WelCome To Admin DashBoard";
            Dashboard.Click += Dashboard_Click;
            // 
            // AdminPortal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(ManageLd);
            Controls.Add(MangeTA);
            Controls.Add(Dashboard);
            Name = "AdminPortal";
            Text = "AdminPortal";
            Load += AdminPortal_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button ManageLd;
        private Button MangeTA;
        private Label Dashboard;
    }
}