﻿/*using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class newrequestsforLDA : Form
    {
        public newrequestsforLDA()
        {
            InitializeComponent();
        }

        private void newrequestsforLDA_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            newrequestsforLDA newrequestsforLDAForm = new newrequestsforLDA();
            newrequestsforLDAForm.Show();
            this.Hide();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }
    }
}
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class newrequestsforLDA : Form
    {
        int id = LoginPage.id;
        int LDAid;
        public newrequestsforLDA()
        {
            InitializeComponent();
        }

        private void newrequestsforLDA_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Studentid.Text))
            {
                LDAid = Convert.ToInt32(Studentid.Text);
                call();
                newrequestsforLDA newrequestsforLDAForm = new newrequestsforLDA();
                newrequestsforLDAForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter LDA Request ID.");
            }
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Studentid.Text))
            {
                LDAid = Convert.ToInt32(Studentid.Text);
                call();
                Student studentForm = new Student();
                studentForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter LDA Request ID.");
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }


        private void call()
        {
            //string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                String query5 = "select * from Eligible_LDA et join Student s on s.StudentId=et.studentId join [User] u on u.ID=s.UserID where et.LdaRequestid =@LDAid and u.ID=@id";
                SqlDataAdapter sda5 = new SqlDataAdapter(query5, SqlConnection);
                sda5.SelectCommand.Parameters.AddWithValue("@LDAid", LDAid);
                sda5.SelectCommand.Parameters.AddWithValue("@id", id);
                DataTable dtable5 = new DataTable();
                sda5.Fill(dtable5);
                if (dtable5.Rows.Count > 0)
                {
                    MessageBox.Show("Student is already eligible for LDA and added");
                    return;
                }
                else
                {


                    string query = "select CourseId from LDARequest where LdaRequestID = @LDAid;";
                    SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                    sda.SelectCommand.Parameters.AddWithValue("@LDAid", LDAid);
                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);
                    int courseId = Convert.ToInt32(dtable.Rows[0]["CourseId"]);

                    string query1 = "select * from StudiedCourse sc" +
                    " join Student s on s.StudentId=sc.StudentID " +
                    " join [User] u on u.ID=s.UserID join " +
                    " Transcript t on t.StudentID=s.StudentId where u.ID=@id and" +
                    " sc.CourseID=@courseId  and t.CGPA>2.0";
                    SqlDataAdapter sda1 = new SqlDataAdapter(query1, SqlConnection);
                    sda1.SelectCommand.Parameters.AddWithValue("@id", id);
                    sda1.SelectCommand.Parameters.AddWithValue("@courseId", courseId);
                    DataTable dtable1 = new DataTable();
                    sda1.Fill(dtable1);
                    if (dtable1.Rows.Count == 0)
                    {
                        MessageBox.Show("Student is not eligible for LDA");
                    }
                    else
                    {
                        string query3 = "select s.StudentId from Student s join [User] u on u.id=s.userId where u.id = @id";
                        SqlDataAdapter sda3 = new SqlDataAdapter(query3, SqlConnection);
                        sda3.SelectCommand.Parameters.AddWithValue("@id", id);
                        DataTable dtable3 = new DataTable();
                        sda3.Fill(dtable3);
                        int StudentId = Convert.ToInt32(dtable3.Rows[0]["StudentId"]);

                        string query2 = "insert into Eligible_LDA values(@studentId,@LdaRequestid)";
                        SqlCommand command = new SqlCommand(query2, SqlConnection);
                        command.Parameters.AddWithValue("@studentId", StudentId);
                        command.Parameters.AddWithValue("@LdaRequestid", LDAid);

                        SqlConnection.Open();
                        command.ExecuteNonQuery();
                        SqlConnection.Close();

                        MessageBox.Show("Student is eligible for LDA and successfully added");
                    }

                }
            }
        }



        /*private void ViewBtn_Click(object sender, EventArgs e)
        {
            string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(connection))
            {
                string query = "select l.LdaRequestID,c.CourseName,f.Name from LdaRequest l" +
                    "join LabDemostrator ld on ld.LabDemostratorID=l.labDemonstrator" +
                    "join Faculty f on f.FacultyId=ld.FactaryID" +
                    "join Courses c on c.CourseID=l.CourseID";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }*/
        private void ViewBtn_Click(object sender, EventArgs e)
        {
            
        }

        private void ViewBtn_Click_1(object sender, EventArgs e)
        {
            //string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select l.LdaRequestID, c.CourseName, f.Name from LdaRequest l " +
                                "join LabDemostrator ld on ld.LabDemostratorID = l.labDemonstrator " +
                                "join Faculty f on f.FacultyId = ld.FactaryID " +
                                "join Courses c on c.CourseID = l.CourseID";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
    }
}
