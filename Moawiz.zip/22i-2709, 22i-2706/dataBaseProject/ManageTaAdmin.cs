﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ManageTaAdmin : Form
    {
        int userid = LoginPage.id;
        public ManageTaAdmin()
        {
            InitializeComponent();

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Studentid.Text))
            {
                MessageBox.Show("Please enter Student ID");
            }
            else
            {
                call();

            }


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }




        private void ViewBtn_Click(object sender, EventArgs e)
        {

        }

        private void ManageTaAdmin_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void ViewBtn_Click_1(object sender, EventArgs e)
        {
            //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "\r\nselect et.EligibleLdID,s.studentId,s.Name," +
                    "f.FacultyId,f.Name,c.CourseID,c.CourseName ," +
                    "ta.Type  from Eligible_Ta et  " +
                    "join TaRequest ta on ta.TaRequestID=et.TaRequestid " +
                    "join Courses c on c.CourseID=ta.CourseID " +
                    "join Teacher t on t.TeacherId=ta.Teacher " +
                    " join Faculty f on f.FacultyId=t.FacultyId" +
                    " join Student s on s.StudentId=et.studentId\r\n";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            AdminPortal adminPortal = new AdminPortal();
            adminPortal.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "select t.Taid,ta.Ta_Assesmentid,s.StudentId,s.Name,f.FacultyId,f.Name,c.CourseID,c.CourseName from TeacherAsisitant t join student s on s.StudentId=t.StudentId join Ta_Assesment ta on ta.Ta_Assesmentid=t.Ta_Assesmentid join Faculty f on f.FacultyId=ta.facultyid join Courses c on c.CourseID=ta.courseid\r\n";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }
        private void call()
        {
            int eligibleid = Convert.ToInt32(Studentid.Text);
            // string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                /*string query = @"SELECT te.FacultyId, t.Type, t.CourseID, et.studentId, et.EligibleLdID, t.TaRequestID
                FROM Eligible_Ta et
                JOIN TaRequest t ON t.TaRequestID = et.TaRequestid
                JOIN Teacher te ON te.TeacherId = t.Teacher
                WHERE et.EligibleLdID =  @eligibleid;";
               

                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@eligibleid", eligibleid);

                DataTable dt = new DataTable();
                sda.Fill(dt);*/
                string query = @"SELECT te.FacultyId, t.Type, t.CourseID, et.studentId, et.EligibleLdID, t.TaRequestID
                                FROM Eligible_Ta et
                                JOIN TaRequest t ON t.TaRequestID = et.TaRequestid
                                JOIN Teacher te ON te.TeacherId = t.Teacher
                                WHERE et.EligibleLdID = @eligibleid;";

                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@eligibleid", eligibleid);

                DataTable dt = new DataTable();
                sda.Fill(dt);




                //write the to get the selected TA from the SelectedTa table using the EligibleLdID
                string query5 = "SELECT SeletedTaId FROM SelectedTa WHERE eligibleid = @eligibleid";
                SqlDataAdapter sda5 = new SqlDataAdapter(query5, SqlConnection);
                sda5.SelectCommand.Parameters.AddWithValue("@eligibleid", eligibleid);
                DataTable dt5 = new DataTable();    
                sda5.Fill(dt5);
                
            

                if (dt.Rows.Count > 0)
                {
                    int courseid = Convert.ToInt32(dt.Rows[0]["CourseID"]);
                    int facultyid = Convert.ToInt32(dt.Rows[0]["FacultyId"]);
                    string type = dt.Rows[0]["Type"].ToString();
                    int studentid = Convert.ToInt32(dt.Rows[0]["studentId"]);
                    int TaRequestid = Convert.ToInt32(dt.Rows[0]["TaRequestID"]);
                     int EligibleLdID = eligibleid;
                    int totalAssigments = 0;

                    // Insert into Ta_Assesment table
                    string insertTaAssesmentQuery = "INSERT INTO Ta_Assesment (courseid, facultyid, totalAssigments, Type) " +
                                                     "VALUES (@courseid, @facultyid, @totalAssigments, @Type)";
                    SqlCommand command = new SqlCommand(insertTaAssesmentQuery, SqlConnection);
                    command.Parameters.AddWithValue("@courseid", courseid);
                    command.Parameters.AddWithValue("@facultyid", facultyid);
                    command.Parameters.AddWithValue("@totalAssigments", totalAssigments);
                    command.Parameters.AddWithValue("@Type", type);

                    SqlConnection.Open();
                    command.ExecuteNonQuery();


                    // Get Ta_Assesmentid
                    string selectTaAssesmentIdQuery = "SELECT Ta_Assesmentid FROM Ta_Assesment WHERE courseid = @courseid AND facultyid = @facultyid";
                    SqlDataAdapter sda1 = new SqlDataAdapter(selectTaAssesmentIdQuery, SqlConnection);
                    sda1.SelectCommand.Parameters.AddWithValue("@courseid", courseid);
                    sda1.SelectCommand.Parameters.AddWithValue("@facultyid", facultyid);
                    DataTable dt1 = new DataTable();
                    sda1.Fill(dt1);
                    int Ta_Assesmentid = Convert.ToInt32(dt1.Rows[0]["Ta_Assesmentid"]);

                    // Insert into TeacherAssistant table
                    string insertTeacherAssistantQuery = "INSERT INTO TeacherAsisitant (Ta_Assesmentid, studentid) " +
                                                          "VALUES (@Ta_Assesmentid, @studentid)";
                    SqlCommand command1 = new SqlCommand(insertTeacherAssistantQuery, SqlConnection);
                    command1.Parameters.AddWithValue("@Ta_Assesmentid", Ta_Assesmentid);
                    command1.Parameters.AddWithValue("@studentid", studentid);
                    command1.ExecuteNonQuery();
                    if (dt5.Rows.Count > 0)
                    {
                        int selectedid = Convert.ToInt32(dt5.Rows[0]["SeletedTaId"]);
                        // Delete from SelectedTa table
                        string deleteSelectedTaQuery = "DELETE FROM SelectedTa WHERE SeletedTaId = @selectedid";
                        SqlCommand command2 = new SqlCommand(deleteSelectedTaQuery, SqlConnection);
                        command2.Parameters.AddWithValue("@selectedid", selectedid);
                        command2.ExecuteNonQuery();
                    }



                    // Delete from Eligible_Ta table
                    string deleteEligibleTaQuery = "DELETE FROM Eligible_Ta WHERE EligibleLdID = @EligibleLdID";
                    SqlCommand command3 = new SqlCommand(deleteEligibleTaQuery, SqlConnection);
                    command3.Parameters.AddWithValue("@EligibleLdID", EligibleLdID);
                    command3.ExecuteNonQuery();

                    // Delete from TaRequest table
                    string deleteTaRequestQuery = "DELETE FROM TaRequest WHERE TaRequestID = @TaRequestid";
                    SqlCommand command4 = new SqlCommand(deleteTaRequestQuery, SqlConnection);
                    command4.Parameters.AddWithValue("@TaRequestid", TaRequestid);
                    command4.ExecuteNonQuery();

                    SqlConnection.Close();

                    MessageBox.Show("Congratulations for becoming TA!");
                }
                else
                {
                    MessageBox.Show("Student is not selected for TA");
                }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Taid = Convert.ToInt32(textBox2.Text);
            int studentid = Convert.ToInt32(textBox4.Text);
            if (string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox4.Text))
            {
                MessageBox.Show("Please enter TA ID and Student ID");
            }
            else
            {

                //                string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

                //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
                using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
                {
                    string query = "UPDATE TeacherAsisitant SET StudentId=@studentid WHERE  Taid= @Taid;";
                    SqlCommand command = new SqlCommand(query, SqlConnection);
                    command.Parameters.AddWithValue("@Taid", Taid);
                    command.Parameters.AddWithValue("@studentid", studentid);
                    SqlConnection.Open();
                    command.ExecuteNonQuery();
                    SqlConnection.Close();
                    MessageBox.Show("TA Updated Successfully");


                }
            }

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click_2(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Taid = Convert.ToInt32(textBox3.Text);
            int Ta_Assesmentid = Convert.ToInt32(textBox1.Text);

            if(string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please enter TA ID and TA Assesment ID");
            }
            else
            {
                // string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
               // string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
                using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
                {
                    //write the querry to delete the TA from the TeacherAssistant table
                    string query = "DELETE FROM TeacherAsisitant WHERE Taid=@Taid ";
                    SqlCommand command = new SqlCommand(query, SqlConnection);
                    command.Parameters.AddWithValue("@Taid", Taid);
                    SqlConnection.Open();
                    command.ExecuteNonQuery();
                    SqlConnection.Close();
                    //write the querry to delete the TA from the Ta_Assesment table
                    string query1 = "DELETE FROM Ta_Assesment WHERE Ta_Assesmentid=@Ta_Assesmentid ";
                    SqlCommand command1 = new SqlCommand(query1, SqlConnection);
                    command1.Parameters.AddWithValue("@Ta_Assesmentid", Ta_Assesmentid);
                    SqlConnection.Open();
                    command1.ExecuteNonQuery();
                    SqlConnection.Close();

                   

                    

                    MessageBox.Show("TA Deleted Successfully");


                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
