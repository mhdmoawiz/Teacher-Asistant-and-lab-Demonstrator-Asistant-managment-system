﻿namespace Project
{
    partial class HireTA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BackButton = new Button();
            viewBtn = new Button();
            HireButon = new Button();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            button2 = new Button();
            textBox2 = new TextBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // BackButton
            // 
            BackButton.BackColor = SystemColors.ControlDark;
            BackButton.ForeColor = Color.Black;
            BackButton.Location = new Point(12, 37);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(106, 28);
            BackButton.TabIndex = 22;
            BackButton.Text = "Back";
            BackButton.UseVisualStyleBackColor = false;
            BackButton.Click += BackButton_Click;
            // 
            // viewBtn
            // 
            viewBtn.BackColor = SystemColors.Highlight;
            viewBtn.ForeColor = SystemColors.Control;
            viewBtn.Location = new Point(678, 83);
            viewBtn.Name = "viewBtn";
            viewBtn.Size = new Size(106, 28);
            viewBtn.TabIndex = 21;
            viewBtn.Text = "view table";
            viewBtn.UseVisualStyleBackColor = false;
            viewBtn.Click += viewBtn_Click;
            // 
            // HireButon
            // 
            HireButon.BackColor = SystemColors.Highlight;
            HireButon.ForeColor = SystemColors.Control;
            HireButon.Location = new Point(678, 233);
            HireButon.Name = "HireButon";
            HireButon.Size = new Size(106, 28);
            HireButon.TabIndex = 20;
            HireButon.Text = "HireBest";
            HireButon.UseVisualStyleBackColor = false;
            HireButon.Click += HireButon_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Arial Narrow", 20.25F, FontStyle.Bold);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(219, 37);
            label1.Name = "label1";
            label1.Size = new Size(331, 31);
            label1.TabIndex = 19;
            label1.Text = "Eligible Candidate For TAship";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(131, 83);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(541, 178);
            dataGridView1.TabIndex = 18;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.Highlight;
            button2.ForeColor = SystemColors.Control;
            button2.Location = new Point(566, 294);
            button2.Name = "button2";
            button2.Size = new Size(106, 28);
            button2.TabIndex = 17;
            button2.Text = "Hire";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.SeaShell;
            textBox2.Location = new Point(269, 294);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(188, 23);
            textBox2.TabIndex = 16;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Arial Narrow", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlText;
            label2.Location = new Point(131, 293);
            label2.Name = "label2";
            label2.Size = new Size(118, 20);
            label2.TabIndex = 23;
            label2.Text = "Eligible Candidte iD";
            // 
            // HireTA
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(BackButton);
            Controls.Add(viewBtn);
            Controls.Add(HireButon);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Controls.Add(button2);
            Controls.Add(textBox2);
            Name = "HireTA";
            Text = "HireTA";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BackButton;
        private Button viewBtn;
        private Button HireButon;
        private Label label1;
        private DataGridView dataGridView1;
        private Button button2;
        private TextBox textBox2;
        private Label label2;
    }
}