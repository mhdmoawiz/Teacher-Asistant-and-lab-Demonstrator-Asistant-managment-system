﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class LDAportel : Form
    {
        public LDAportel()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LDApayment lDApaymentForm = new LDApayment();
            lDApaymentForm.Show();
            this.Hide();
        }

        private void ViewBtn_Click(object sender, EventArgs e)
        {

        }

        private void ViewBtn_Click_1(object sender, EventArgs e)
        {
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                //  string query = "SELECT s.StudentId, s.Name, la.ADate, la.AStatus FROM LdAttendance la JOIN LabDemostratorAsisitant ld ON ld.Ldid = la.Ldid JOIN Student s ON s.StudentId = ld.StudentId JOIN [User] u ON u.ID = s.UserID WHERE u.ID = @id;\r\n";

                string query = "SELECT s.StudentId, s.Name, la.ADate, la.AStatus " +
               "FROM " +
               "( " +
               "    SELECT la.Ldid, la.ADate, la.AStatus " +
               "    FROM LdAttendance la " +
               ") la " +
               "JOIN " +
               "( " +
               "    SELECT ld.Ldid, ld.StudentId " +
               "    FROM LabDemostratorAsisitant ld " +
               ") ld ON ld.Ldid = la.Ldid " +
               "JOIN " +
               "( " +
               "    SELECT s.StudentId, s.Name " +
               "    FROM Student s " +
               ") s ON s.StudentId = ld.StudentId " +
               "JOIN " +
               "( " +
               "    SELECT u.ID " +
               "    FROM [User] u " +
               ") u ON u.ID = s.UserID " +
               "WHERE " +
               "    u.ID = @id;";

                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@id", LoginPage.id);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
