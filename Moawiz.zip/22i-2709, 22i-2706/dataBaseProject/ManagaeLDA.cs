﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Project
{
    public partial class ManagaeLDA : Form
    {
        int id = LoginPage.id;
        public ManagaeLDA()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Faculty facultyForm = new Faculty();
            facultyForm.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void data()
        {
            //string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";


            using (SqlConnection connections = new SqlConnection(LoginPage.connection))
            {
                /*string query = "SELECT DISTINCT s.StudentId, c.CourseName, F.Name AS FacultyName, COUNT(LDAT.ADate) AS DaysPresent " +
                  "FROM LabDemostratorAsisitant lda " +
                  "INNER JOIN LdAttendance ldat ON lda.Ldid = ldat.Ldid " +
                  "INNER JOIN Student S ON S.StudentId = lda.StudentId " +
                  "INNER JOIN Courses c ON c.CourseID = lda.courseid " +
                  "INNER JOIN LabDemostrator LD ON LD.LabDemostratorID = LDA.LabDemostratorId " +
                  "INNER JOIN Faculty f ON F.FacultyId = LD.FactaryID " +
                  "INNER JOIN [User] u ON u.ID = F.UserID AND u.ID = @id " +
                  "WHERE LDAT.AStatus = 'P' " +
                  "GROUP BY s.StudentId, c.CourseName, F.Name";*/
                string query = @"SELECT 
                    s.StudentId, 
                    s.Name, 
                    c.CourseName 
                FROM 
                    [User] u
                JOIN 
                    Faculty f ON f.UserID = u.ID
                JOIN 
                    LabDemostrator ld ON ld.FactaryID = f.FacultyId
                JOIN 
                    LabDemostratorAsisitant lda ON lda.LabDemostratorId = ld.LabDemostratorID
                JOIN 
                    Student s ON s.StudentId = lda.StudentId
                JOIN 
                    Courses c ON c.CourseID = lda.courseid
                WHERE 
                    u.ID = 63";




                // Now you can use the 'queryString' variable wherever you need the SQL query as a string.

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connections))
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@id", id);
                    DataTable dataTable = new DataTable();

                    try
                    {

                        connections.Open();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }

                }
            }

        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            //string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            string studentName = StudentName.Text;
            string courseName = textBox6.Text;
            String attendance;

            if (checkBox1.Checked)
            {
                attendance = "p";

            }
            else
            {
                attendance = "A";
            }


            if (string.IsNullOrWhiteSpace(studentName) || string.IsNullOrWhiteSpace(courseName))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }


            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = @"SELECT 
                   *
                FROM 
                    LabDemostratorAsisitant lda 
                JOIN 
                    Student s ON s.StudentId = lda.StudentId 
                JOIN 
                    Courses c ON c.CourseID = lda.courseid 
                WHERE 
                    c.CourseName = @CN AND 
                    s.Name = @SN;";



                SqlDataAdapter sd1 = new SqlDataAdapter(query, SqlConnection);
                sd1.SelectCommand.Parameters.AddWithValue("@SN", studentName);
                sd1.SelectCommand.Parameters.AddWithValue("@CN", courseName);
                DataTable dtable1 = new DataTable();
                sd1.Fill(dtable1);

                if (dtable1.Rows.Count > 0)
                {
                    int Ldid = Convert.ToInt32(dtable1.Rows[0]["Ldid"]);

                    string insertQuery = "INSERT INTO LdAttendance (Adate, AStatus, Ldid) VALUES (@Adate, @AStatus, @id)";


                    using (SqlCommand cmd = new SqlCommand(insertQuery, SqlConnection))
                    {
                        DateTime todaysDate = DateTime.Today;
                        cmd.Parameters.AddWithValue("@id", Ldid);
                        cmd.Parameters.AddWithValue("@Adate", todaysDate);
                        cmd.Parameters.AddWithValue("@AStatus", attendance);

                        try
                        {
                            SqlConnection.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Attendace updated successfully.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No LDA found for the specified  course.");
                }
            }


        }

        private void ViewBtn_Click(object sender, EventArgs e)
        {
            data();
        }

        private void StudentName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
