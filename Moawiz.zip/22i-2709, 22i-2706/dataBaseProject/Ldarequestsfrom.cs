﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Project
{
    public partial class Ldarequestsfrom : Form
    {

        int id = LoginPage.id;
        public Ldarequestsfrom()
        {
            InitializeComponent();
            data();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Faculty facultyForm = new Faculty();
            facultyForm.Show();
            this.Hide();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
             }

        private void data()
        {

            
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

         //   string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection connections = new SqlConnection(LoginPage.connection))
            {
                string query = @"
    SELECT ld.LabDemostratorID, f.Name, c.CourseName
    FROM [user] u 
    INNER JOIN Faculty f ON u.ID = f.UserID 
    INNER JOIN LabDemostrator ld ON f.FacultyId = ld.FactaryID
    INNER JOIN CourseFaculty cf ON ld.FactaryID = cf.FacultyID
    INNER JOIN Courses c ON cf.CourseID = c.CourseID 
    WHERE u.id = @Id;
";

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connections))
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@Id", id);
                    DataTable dataTable = new DataTable();

                    try
                    {

                        connections.Open();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }

                }
            }

        }
        private void LoginButton_Click(object sender, EventArgs e)
        {
         
            int courseId;
            int facultyid;
            int Ldid;
            // string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            string coursename = CourseName.Text;
            string facultyname = FacultyName.Text;

            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                
                    // Get CourseID
                    string query = "SELECT CourseID FROM Courses WHERE CourseName = @Coursename;";
                    SqlDataAdapter sd1 = new SqlDataAdapter(query, SqlConnection);
                    sd1.SelectCommand.Parameters.AddWithValue("@Coursename", coursename);
                    DataTable dtable1 = new DataTable();
                    sd1.Fill(dtable1);

                    if (dtable1.Rows.Count > 0)
                    {
                        courseId = Convert.ToInt32(dtable1.Rows[0]["CourseID"]);

                        // Get FacultyID
                        string query1 = "SELECT f.FacultyId FROM LabDemostrator ld INNER JOIN Faculty f ON ld.FactaryID = f.FacultyId AND f.Name = @facultyname;";
                        SqlDataAdapter sd2 = new SqlDataAdapter(query1, SqlConnection);
                        sd2.SelectCommand.Parameters.AddWithValue("@facultyname", facultyname);
                        DataTable dtable2 = new DataTable();
                        sd2.Fill(dtable2);

                        if (dtable2.Rows.Count > 0)
                        {
                            facultyid = Convert.ToInt32(dtable2.Rows[0]["FacultyId"]);

                            // Check if faculty is teaching this course
                            string query2 = @"
                                 SELECT tr.LabDemostratorID
                                FROM LabDemostrator tr 
                                 INNER JOIN Faculty f ON tr.FactaryID = f.FacultyId
                             INNER JOIN CourseFaculty cf ON cf.FacultyID = f.FacultyId
                          INNER JOIN Courses c ON c.CourseID = cf.CourseID
                         WHERE c.CourseID = @courseId AND f.FacultyId = @facultyid";



                            SqlDataAdapter sd3 = new SqlDataAdapter(query2, SqlConnection);
                            sd3.SelectCommand.Parameters.AddWithValue("@courseId", courseId);
                            sd3.SelectCommand.Parameters.AddWithValue("@facultyid", facultyid);


                            DataTable dtable3 = new DataTable();
                            sd3.Fill(dtable3);

                            if (dtable3.Rows.Count > 0)
                            {
                                Ldid = Convert.ToInt32(dtable3.Rows[0]["LabDemostratorID"]);

                                // Check if request already exists
                                string query5 = "SELECT LdaRequestID FROM LdaRequest WHERE CourseID = @courseId AND labDemonstrator = @Ldid";
                                SqlDataAdapter sd5 = new SqlDataAdapter(query5, SqlConnection);
                                sd5.SelectCommand.Parameters.AddWithValue("@courseId", courseId);
                                sd5.SelectCommand.Parameters.AddWithValue("@Ldid", Ldid);
                                DataTable dtable5 = new DataTable();
                                sd5.Fill(dtable5);

                                if (dtable5.Rows.Count == 0)
                                {
                                    // Insert request
                                    string query4 = "INSERT INTO LdaRequest (CourseID, labDemonstrator) VALUES (@courseId, @Ldid)";
                                    SqlCommand cmd = new SqlCommand(query4, SqlConnection);
                                    cmd.Parameters.AddWithValue("@courseId", courseId);
                                    cmd.Parameters.AddWithValue("@Ldid", Ldid);
                                    SqlConnection.Open();
                                    cmd.ExecuteNonQuery();
                                    SqlConnection.Close();
                                MessageBox.Show("Request Compeleted.");
                            }
                                else
                                {
                                    MessageBox.Show("Request already exists.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("You are not teaching this course.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Faculty not found.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Course not found.");
                    }
                    CourseName.Clear();
                FacultyName.Clear();
                
                
            }
        }
    }
}
