﻿/*using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class TAportel : Form
    {
        public TAportel()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TApayment tApaymentForm = new TApayment();
            tApaymentForm.Show();
            this.Hide();

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();

        }
    }
}
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class TAportel : Form
    {
        public TAportel()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TApayment tApaymentForm = new TApayment();
            tApaymentForm.Show();
            this.Hide();

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Student studentForm = new Student();
            studentForm.Show();
            this.Hide();

        }

        private void ViewBtn_Click(object sender, EventArgs e)
        {


        }

        private void ViewBtn_Click_1(object sender, EventArgs e)
        {
            //string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";

            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = @"SELECT
                    s.UserID,
                    s.Name,
                    c.CourseName,
                    f.Name AS Faculty_name,
                    ta.totalAssigments
                FROM
                    (
                        SELECT
                            ta.Ta_Assesmentid,
                            ta.totalAssigments,
                            ta.courseid,
                            ta.facultyid
                        FROM
                            Ta_Assesment ta
                    ) ta
                JOIN
                    (
                        SELECT
                            t.Ta_Assesmentid,
                            t.StudentId
                        FROM
                            TeacherAsisitant t
                    ) t ON t.Ta_Assesmentid = ta.Ta_Assesmentid
                JOIN
                    (
                        SELECT
                            c.CourseID,
                            c.CourseName
                        FROM
                            Courses c
                    ) c ON c.CourseID = ta.courseid
                JOIN
                    (
                        SELECT
                            f.FacultyId,
                            f.Name
                        FROM
                            Faculty f
                    ) f ON f.FacultyId = ta.facultyid
                JOIN
                    (
                        SELECT
                            s.StudentId,
                            s.Name,
                            s.UserID
                        FROM
                            Student s
                    ) s ON s.StudentId = t.StudentId
                JOIN
                    (
                        SELECT
                            u.ID
                        FROM
                            [User] u
                    ) u ON u.ID = s.UserID
                WHERE
                    u.ID = @id;";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@id", LoginPage.id);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }

        private void TAportel_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
