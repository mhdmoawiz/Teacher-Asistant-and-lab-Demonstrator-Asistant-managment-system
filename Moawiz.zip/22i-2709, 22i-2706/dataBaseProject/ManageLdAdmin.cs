﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ManageLdAdmin : Form
    {
        public ManageLdAdmin()
        {
            InitializeComponent();
        }

        private void ManageLdAdmin_Load(object sender, EventArgs e)
        {

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            AdminPortal adminPortal = new AdminPortal();
            adminPortal.Show();
            this.Hide();
        }

        private void ViewBtn_Click(object sender, EventArgs e)
        {
            // string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
           // string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = @"
                                SELECT 
                                    et.EligibleLdID,
                                    s.studentId,
                                    s.Name AS StudentName,
                                    f.FacultyId,
                                    f.Name AS FacultyName,
                                    c.CourseID,
                                    c.CourseName
                                FROM 
                                    Eligible_LDA et  
                                JOIN 
                                    LdaRequest ta ON ta.LdaRequestID = et.LdaRequestid 
                                JOIN 
                                    Courses c ON c.CourseID = ta.CourseID 
                                JOIN 
                                    LabDemostrator t ON t.LabDemostratorID = ta.labDemonstrator
                                JOIN 
                                    Faculty f ON f.FacultyId = t.FactaryID
                                JOIN 
                                    Student s ON s.StudentId = et.studentId;
                            ";

                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
           // string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = @"
                                SELECT 
                                    ld.Ldid,
                                    s.StudentId,
                                    s.StudentId,
                                    l.LabDemostratorID,
                                    f.Name AS FacultyName,
                                    c.CourseID,
                                    c.CourseName 
                                FROM 
                                    LabDemostratorAsisitant ld
                                JOIN 
                                    Student s ON s.StudentId = ld.StudentId
                                JOIN 
                                    LabDemostrator l ON l.LabDemostratorId = ld.LabDemostratorId
                                JOIN 
                                    Faculty f ON f.FacultyId = l.FactaryID
                                JOIN 
                                    Courses c ON c.CourseID = ld.courseid";

                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Studentid.Text))
            {
                MessageBox.Show("Please fill in the eligible ID.");
            }
            else
            {
                call();
            }

        }
    
        private void call()
        {
            int eligibleid;
            if (!int.TryParse(Studentid.Text, out eligibleid))
            {
                MessageBox.Show("Please enter a valid eligible ID.");
                return;
            }

            //   string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
            using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
            {
                string query = "SELECT * FROM Eligible_LDA el JOIN LdaRequest lr ON lr.LdaRequestID = el.LdaRequestid where el.EligibleLdID=@EligibleLdID";
                SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                sda.SelectCommand.Parameters.AddWithValue("@EligibleLdID", eligibleid);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("There are no eligible candidates yet.");
                    return;
                }

                int courseid = Convert.ToInt32(dt.Rows[0]["CourseID"]);
                int labDemonstratorid = Convert.ToInt32(dt.Rows[0]["labDemonstrator"]);
                int studentid = Convert.ToInt32(dt.Rows[0]["studentId"]);
                int LDARequestid = Convert.ToInt32(dt.Rows[0]["LdaRequestID"]);
                int EligibleLdID = eligibleid;

                // Insert into LabDemostratorAsisitant table
                string insertQuery = "INSERT INTO LabDemostratorAsisitant (studentId, CourseID, LabDemostratorId) VALUES (@studentId, @CourseID, @labDemonstrator)";
                SqlCommand command = new SqlCommand(insertQuery, SqlConnection);
                command.Parameters.AddWithValue("@studentId", studentid);
                command.Parameters.AddWithValue("@CourseID", courseid);
                command.Parameters.AddWithValue("@labDemonstrator", labDemonstratorid);
                SqlConnection.Open();
                command.ExecuteNonQuery();

                //write a query to get the selected LDA from the Selected_LDA table using eligibleLdID
                string getSelectedLdaQuery = "SELECT SeletedLda FROM Selected_LDA WHERE eligible = @EligibleLdID";
                SqlCommand getSelectedLdaCommand = new SqlCommand(getSelectedLdaQuery, SqlConnection);
                getSelectedLdaCommand.Parameters.AddWithValue("@EligibleLdID", EligibleLdID);
                DataTable dataTable5 = new DataTable();
                SqlDataAdapter sqlDataAdapter5 = new SqlDataAdapter(getSelectedLdaCommand);
                sqlDataAdapter5.Fill(dataTable5);
                if (dataTable5.Rows.Count > 0)
                {
                    MessageBox.Show("There is no selected LDA for this eligible LDA");

                    int selectedLDid = Convert.ToInt32(dataTable5.Rows[0]["SeletedLda"]);

                    // Delete from Selected_LDA table
                    string deleteSelectedLdaQuery = "DELETE FROM Selected_LDA WHERE SeletedLda = @selectedLDid";
                    SqlCommand deleteSelectedLdaCommand = new SqlCommand(deleteSelectedLdaQuery, SqlConnection);
                    deleteSelectedLdaCommand.Parameters.AddWithValue("@selectedLDid", selectedLDid);
                    deleteSelectedLdaCommand.ExecuteNonQuery();
                }

                // Delete from Eligible_LDA table
                string deleteEligibleLdaQuery = "DELETE FROM Eligible_LDA WHERE EligibleLdID = @EligibleLdID";
                SqlCommand deleteEligibleLdaCommand = new SqlCommand(deleteEligibleLdaQuery, SqlConnection);
                deleteEligibleLdaCommand.Parameters.AddWithValue("@EligibleLdID", EligibleLdID);
                deleteEligibleLdaCommand.ExecuteNonQuery();

                // Delete from LdaRequest table
                string deleteLdaRequestQuery = "DELETE FROM LdaRequest WHERE LdaRequestID = @LDARequestid";
                SqlCommand deleteLdaRequestCommand = new SqlCommand(deleteLdaRequestQuery, SqlConnection);
                deleteLdaRequestCommand.Parameters.AddWithValue("@LDARequestid", LDARequestid);
                deleteLdaRequestCommand.ExecuteNonQuery();

                SqlConnection.Close();

                MessageBox.Show("You are successfully added as Lab Demonstrator Assistant");
            }
        }



        private void Studentid_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int ldaid = Convert.ToInt32(textBox2.Text);
            int studentid = Convert.ToInt32(textBox4.Text);
            if (string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox4.Text))
            {
                MessageBox.Show("Please enter ldA ID and Student ID");
            }
            else
            {
                //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
               // string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
                using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
                {
                    string query = "UPDATE LabDemostratorAsisitant SET StudentId=@studentid WHERE  Ldid= @ldaid;";
                    SqlCommand command = new SqlCommand(query, SqlConnection);
                    command.Parameters.AddWithValue("@ldaid", ldaid);
                    command.Parameters.AddWithValue("@studentid", studentid);
                    SqlConnection.Open();
                    command.ExecuteNonQuery();
                    SqlConnection.Close();
                    MessageBox.Show("LDA Updated Successfully");


                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Ldaid = Convert.ToInt32(textBox3.Text);
           
            if (string.IsNullOrEmpty(textBox3.Text) )
            {
                MessageBox.Show("Please enter LDA ID ");
            }
            else
            {
                //  string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
                //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
                using (SqlConnection SqlConnection = new SqlConnection(LoginPage.connection))
                {
                    //write the querry to delete the TA from the TeacherAssistant table
                    string query = "DELETE FROM LdAttendance WHERE ldid=@Ldaid ";
                    SqlCommand command = new SqlCommand(query, SqlConnection);
                    command.Parameters.AddWithValue("@Ldaid", Ldaid);
                    SqlConnection.Open();
                    command.ExecuteNonQuery();
                    SqlConnection.Close();

                    //write the querry to delete the TA from the Ta_Assesment table
                    string query1 = "DELETE FROM LabDemostratorAsisitant WHERE ldid=@Ldaid ";
                    SqlCommand command1 = new SqlCommand(query1, SqlConnection);
                    command1.Parameters.AddWithValue("@Ldaid", Ldaid);
                    SqlConnection.Open();
                    command1.ExecuteNonQuery();
                    SqlConnection.Close();

                    MessageBox.Show("TA Deleted Successfully");


                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
