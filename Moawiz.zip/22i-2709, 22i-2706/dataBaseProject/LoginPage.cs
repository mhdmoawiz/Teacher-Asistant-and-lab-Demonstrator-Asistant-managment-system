﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{

    public partial class LoginPage : Form
    {
        public static string connection = @"Data Source=DESKTOP-2FRU7FM\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
        public static int id;
        public LoginPage()
        {
            InitializeComponent();
        }

        private void LoginPage_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void login_TextChanged(object sender, EventArgs e)
        {

        }

        private void password_TextChanged(object sender, EventArgs e)
        {

        }
        private void LoginButton_Click(object sender, EventArgs e)
        {
            string username = login.Text;
            string password = Password.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please fill in the username and password.");
            }
            else
            {
                //string connection = @"Data Source=success\sqlexpress01;Initial Catalog=Project;Integrated Security=True;Encrypt=False;";
                
                using (SqlConnection SqlConnection = new SqlConnection(connection))
                {
                    string query = "SELECT ID FROM [User] WHERE UserId = @username AND Password = @password;";
                    SqlDataAdapter sda = new SqlDataAdapter(query, SqlConnection);
                    sda.SelectCommand.Parameters.AddWithValue("@username", username);
                    sda.SelectCommand.Parameters.AddWithValue("@password", password);

                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);

                    if (dtable.Rows.Count > 0)
                    {
                        id = Convert.ToInt32(dtable.Rows[0]["ID"]);

                        char firstChar = username[0];
                        if (char.IsLetter(firstChar))
                        {

                            // Faculty
                            Faculty f = new Faculty();
                            f.Show();
                            this.Hide();


                        }
                        else if (firstChar == '2')
                        {
                            // Student
                            Student s = new Student();
                            s.Show();
                        }
                        else if (firstChar == '1')
                        {
                            AdminPortal Ap = new AdminPortal();
                            Ap.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Invalid user type.");
                        }

                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password.");
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
