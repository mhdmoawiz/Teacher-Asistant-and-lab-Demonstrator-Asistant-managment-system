﻿namespace Project
{
    partial class Faculty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button3 = new Button();
            button1 = new Button();
            ManageLd = new Button();
            MangeTA = new Button();
            RequestForLd = new Button();
            requestForTa = new Button();
            Dashboard = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackColor = SystemColors.Highlight;
            button2.ForeColor = SystemColors.ControlLightLight;
            button2.Location = new Point(499, 252);
            button2.Name = "button2";
            button2.Size = new Size(213, 32);
            button2.TabIndex = 20;
            button2.Text = "Hire LDA";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.Highlight;
            button3.ForeColor = SystemColors.ButtonHighlight;
            button3.Location = new Point(147, 252);
            button3.Name = "button3";
            button3.Size = new Size(213, 32);
            button3.TabIndex = 19;
            button3.Text = "Hire TA";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Beige;
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(30, 377);
            button1.Name = "button1";
            button1.Size = new Size(108, 32);
            button1.TabIndex = 18;
            button1.Text = "Sign Out";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // ManageLd
            // 
            ManageLd.BackColor = SystemColors.Highlight;
            ManageLd.ForeColor = SystemColors.ButtonHighlight;
            ManageLd.Location = new Point(499, 189);
            ManageLd.Name = "ManageLd";
            ManageLd.Size = new Size(213, 32);
            ManageLd.TabIndex = 17;
            ManageLd.Text = "Manage LDA";
            ManageLd.UseVisualStyleBackColor = false;
            ManageLd.Click += ManageLd_Click;
            // 
            // MangeTA
            // 
            MangeTA.BackColor = SystemColors.Highlight;
            MangeTA.ForeColor = SystemColors.ButtonHighlight;
            MangeTA.Location = new Point(147, 189);
            MangeTA.Name = "MangeTA";
            MangeTA.Size = new Size(213, 32);
            MangeTA.TabIndex = 16;
            MangeTA.Text = "Manage TA";
            MangeTA.UseVisualStyleBackColor = false;
            MangeTA.Click += MangeTA_Click_1;
            // 
            // RequestForLd
            // 
            RequestForLd.BackColor = SystemColors.Highlight;
            RequestForLd.ForeColor = SystemColors.ButtonHighlight;
            RequestForLd.Location = new Point(499, 125);
            RequestForLd.Name = "RequestForLd";
            RequestForLd.Size = new Size(213, 32);
            RequestForLd.TabIndex = 15;
            RequestForLd.Text = "Request For LDA";
            RequestForLd.UseVisualStyleBackColor = false;
            RequestForLd.Click += RequestForLd_Click;
            // 
            // requestForTa
            // 
            requestForTa.BackColor = SystemColors.Highlight;
            requestForTa.ForeColor = SystemColors.ButtonHighlight;
            requestForTa.Location = new Point(147, 125);
            requestForTa.Name = "requestForTa";
            requestForTa.Size = new Size(213, 32);
            requestForTa.TabIndex = 14;
            requestForTa.Text = "Request For TA";
            requestForTa.UseVisualStyleBackColor = false;
            requestForTa.Click += requestForTa_Click;
            // 
            // Dashboard
            // 
            Dashboard.AutoSize = true;
            Dashboard.BackColor = SystemColors.GradientActiveCaption;
            Dashboard.Font = new Font("Arial Narrow", 26.25F, FontStyle.Bold);
            Dashboard.ForeColor = SystemColors.Desktop;
            Dashboard.Location = new Point(180, 44);
            Dashboard.Name = "Dashboard";
            Dashboard.Size = new Size(467, 42);
            Dashboard.TabIndex = 13;
            Dashboard.Text = "WelCome To Faculty DashBoard";
            Dashboard.Click += Dashboard_Click;
            // 
            // Faculty
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(ManageLd);
            Controls.Add(MangeTA);
            Controls.Add(RequestForLd);
            Controls.Add(requestForTa);
            Controls.Add(Dashboard);
            Name = "Faculty";
            Text = "Faculty";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button3;
        private Button button1;
        private Button ManageLd;
        private Button MangeTA;
        private Button RequestForLd;
        private Button requestForTa;
        private Label Dashboard;
    }
}