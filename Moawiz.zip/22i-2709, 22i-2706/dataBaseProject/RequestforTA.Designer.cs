﻿namespace Project
{
    partial class RequestforTA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            label3 = new Label();
            FacultyName = new TextBox();
            label2 = new Label();
            LoginButton = new Button();
            CourseName = new TextBox();
            BackButton = new Button();
            label1 = new Label();
            label4 = new Label();
            type = new TextBox();
            label5 = new Label();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Arial Narrow", 12F);
            label3.ForeColor = SystemColors.Desktop;
            label3.Location = new Point(182, 201);
            label3.Name = "label3";
            label3.Size = new Size(90, 20);
            label3.TabIndex = 50;
            label3.Text = "Faculty Name";
            // 
            // FacultyName
            // 
            FacultyName.BackColor = Color.White;
            FacultyName.Location = new Point(278, 201);
            FacultyName.Name = "FacultyName";
            FacultyName.Size = new Size(177, 23);
            FacultyName.TabIndex = 49;
            FacultyName.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Arial Narrow", 12F);
            label2.ForeColor = SystemColors.Desktop;
            label2.Location = new Point(181, 159);
            label2.Name = "label2";
            label2.Size = new Size(91, 20);
            label2.TabIndex = 48;
            label2.Text = "Course Name";
            // 
            // LoginButton
            // 
            LoginButton.BackColor = SystemColors.HotTrack;
            LoginButton.ForeColor = SystemColors.ActiveCaptionText;
            LoginButton.Location = new Point(278, 302);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(95, 33);
            LoginButton.TabIndex = 47;
            LoginButton.Text = "Add";
            LoginButton.UseVisualStyleBackColor = false;
            LoginButton.Click += LoginButton_Click;
            // 
            // CourseName
            // 
            CourseName.BackColor = Color.White;
            CourseName.Location = new Point(278, 156);
            CourseName.Name = "CourseName";
            CourseName.Size = new Size(177, 23);
            CourseName.TabIndex = 46;
            CourseName.TextAlign = HorizontalAlignment.Center;
            // 
            // BackButton
            // 
            BackButton.BackColor = SystemColors.ControlDark;
            BackButton.ForeColor = Color.Black;
            BackButton.Location = new Point(35, 38);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(106, 28);
            BackButton.TabIndex = 45;
            BackButton.Text = "Back";
            BackButton.UseVisualStyleBackColor = false;
            BackButton.Click += BackButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Arial Narrow", 20.25F, FontStyle.Bold);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(167, 78);
            label1.Name = "label1";
            label1.Size = new Size(313, 31);
            label1.TabIndex = 44;
            label1.Text = "Teacher Assistance Request";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.Desktop;
            label4.Location = new Point(473, 125);
            label4.Name = "label4";
            label4.Size = new Size(101, 18);
            label4.TabIndex = 52;
            label4.Text = "Your Courses";
            // 
            // type
            // 
            type.BackColor = Color.White;
            type.Location = new Point(278, 248);
            type.Name = "type";
            type.Size = new Size(177, 23);
            type.TabIndex = 53;
            type.TextAlign = HorizontalAlignment.Center;
            type.TextChanged += type_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Arial Narrow", 12F);
            label5.ForeColor = SystemColors.Desktop;
            label5.Location = new Point(190, 247);
            label5.Name = "label5";
            label5.Size = new Size(82, 20);
            label5.TabIndex = 54;
            label5.Text = "CourseType";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Window;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.Control;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.Location = new Point(473, 146);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(298, 144);
            dataGridView1.TabIndex = 55;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick_1;
            // 
            // RequestforTA
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridView1);
            Controls.Add(label5);
            Controls.Add(type);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(FacultyName);
            Controls.Add(label2);
            Controls.Add(LoginButton);
            Controls.Add(CourseName);
            Controls.Add(BackButton);
            Controls.Add(label1);
            ForeColor = SystemColors.Control;
            Name = "RequestforTA";
            Text = "RequestforTA";
            Load += RequestforTA_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private TextBox FacultyName;
        private Label label2;
        private Button LoginButton;
        private TextBox CourseName;
        private Button BackButton;
        private Label label1;
        private Label label4;
        private TextBox type;
        private Label label5;
        private DataGridView dataGridView1;
    }
}